<?php
/**
 * This is the login users script to log in users
 * when given with username and password
 * 
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @license http://thebestfreelancer.in The Best Freelancer. India
 * @version Build 1.0
 * @package JKDiag
 * @copyright (c) 2014, The Best Freelancer
 * @outputBuffering disabled
 */

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
if (isLogged() !== false){redirectUser();}
// clean the submitted data
$submittedData                  = DataFilter::getObject()->cleanData($_POST);
// make a sql to fetch if user exists
$sql = 'select staff_id, staff_name, staff_uname, staff_privilage from staff_users';
$sql .= ' where staff_uname = ?';
$sql .= ' and staff_pwd = ?';
$sql .= ' and is_active = ?';
// fetch the data via sql
$result = DbOperations::getObject()->fetchData(
    $sql, 
    [
        $submittedData['uname'],
        DataFilter::getObject()->pwdHash($submittedData['pass']),
        1
    ]
);
//var_dump(DataFilter::getObject()->pwdHash($submittedData['pass']));exit;
// test if data is fetched
if (is_array($result) and (count($result) > 0)) {
    // set the fetched details in session to be easily usable
    $_SESSION['UID'] = $result[0]['staff_id'];
    $_SESSION['USERTYPE'] = $result[0]['staff_privilage'];
    $_SESSION['NAME'] = $result[0]['staff_name'];
    $_SESSION['USERNAME'] = $result[0]['staff_uname'];
    session_write_close();
    redirectUser();
} else {
    $_SESSION['STATUS'] = 'error';
    $_SESSION['MSG'] = 'Incorrect credentials';
    session_write_close();
    header('Location:' . ACCESS_URL);
    exit;
}
