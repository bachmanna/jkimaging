<?php

/**
 * This is the common configuration file to be included all over the project
 * and it contains the required constants and variables that will be commonly used
 * New functionality and classes can be added via class files but this file should
 * remain intact if possible.
 * 
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @license http://thebestfreelancer.in The Best Freelancer. India
 * @version Build 1.0
 * @package JKDiag
 * @copyright (c) 2014, The Best Freelancer
 * @outputBuffering disabled
 */

session_start();
/*
 * set the error handler in ALL, DEPRICATED & STRICT mode
 * so that no errors (not even syntactical) can be tolerated
 */
error_reporting(E_ALL | E_DEPRECATED | E_STRICT);

/*
 * set default time-zone to confirm the timezone
 * else it will show an error that system time is not reliable
 * Change it as per your timezone
 */
date_default_timezone_set('Asia/Kolkata');

/*
 * set maximum script execution time to overcome
 * timeout situations
 * I have set it for 5 minutes, i.e. 5 mins * 60 seconds,
 * But dont use unlimited or too much time as it may cause
 * too much server load and even breakdown
 */
set_time_limit(5 * 60);


/**
 * Define commonly used Constants so that using them will be easier
 * Here we've tried to name the constants in capitals so that they can be
 * distinguished clearly without any confusion, which is a standard also
 * Hence I'm going to name all GLOBALS & CONSTANTS in CAPITALS
 * Variables in camelCase,
 * private, protected properties and methods with _underscrore
 * and all pear2 standards of coding PHP
 * @link http://pear.php.net/manual/en/coding-standards.php for more info
 */
// define the server or host
define('HOST', $_SERVER['HTTP_HOST']);
/*
 * define the installed directory name
 * as this file is inside 'classes' directory, we must go one level
 * up to get the base directory name
 */
define('INSTALL_DIR', basename(dirname(dirname(__FILE__))));

// define complete host url by adding two slashes at start and end
define('ACCESS_URL', 'http://' . HOST. (INSTALL_DIR === '' ? '/' : '/'.INSTALL_DIR.'/'));

// define directory separator
define('DS', DIRECTORY_SEPARATOR);

// define complete directory path in order to get the actual directory path relative to the system
define('DIRPATH', dirname(dirname(__FILE__)));

// define current date
define('CURDATE', date('d-m-Y'));

// define current time
define('CURTIME', date('h:i:s A'));

// define database format date
define('DBDATE', date('Y-m-d'));

// define database format time
define('DBTIME', date('H:i:s'));

// define database timestamp
define('DBTIMESTAMP', date('Y-m-d H:i:s'));

/************************************************************************************************************
 * Database details start here, we have to define all the database details so that
 * those can be connected via those credentials.
 */

// define database host
define('DBHOST', 'localhost');

// define database driver
define('DRIVER', 'mysql');

// define database name
define('DBNAME', 'jkimg');

// define database username
define('DBUSER', 'root');

// define database password
define('DBPASS', 'TECH2');

/**
 * define a security salt to encrypt password
 * This is used for password encryption which is
 * irreversible and don't ever change after you
 * have logged out of admin panel, else you may
 * never reset your password.
 * CAUTION
 * If you want to change the salt, contact the author
 */
define('SECURITY_SALT', 'lkhhlkLLlk*&%67445_7!~lLKJHkjhkut');

/**
 * Function to autoload class files needed dynamically when new instance of the class is created
 * This autoload function need not be called but automatically fired
 * 
 * @package RegistrationSystem
 * @param string $className The name of the class which is called
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @access public
 * @category CommonFunction
 * @link http://www.php.net/manual/en/function.autoload.php The autoload function documentation
 */
spl_autoload_register(function($className) {
    /**
     * variable to store the filename of the class
     * The common style is to make the string into lowercase
     * and append .class.php in order to make the class file name
     * Same is also followed to name a class file
     * 
     * @var string The class file name
     * @access private
     */
    $fileName                   = strtolower($className).'.class.php';
    // check if the file exists
    if (file_exists(DIRPATH . DS . 'classes' . DS . $fileName)) {
        // if exists, require it
        require_once DIRPATH . DS . 'classes' . DS . $fileName;
    } else {
        die('The required class file not found');
    }
});

/*
 * Redirect to user directory accordingly
 */
if (!function_exists('redirectUser')) {
    /**
     * Redirect user if not allowed user group
     * 
     * @package JKIMG
     * @author Kirti Kumar <admin@thebestfreelancer.in>
     * @access public
     * @category CommonFunctions
     * 
     * @param int $allowedUserGroupId The User Group Id like 1/2/reception for admin/user/reception
     * @return void Only redirects if not permitted
     */
    function redirectUser() {
        if (isLogged() !== false) {
            switch (isLogged()) {
                case '1':
                    $home = 'admin';
                    break;
                case '2':
                    $home = 'user';
                    break;
                case '3':
                    $home = 'reception/patient.php?opt=newPatient';
                    break;
                default:
                    $home = 'logout.php';
                    break;
            }
            header('Location:' . ACCESS_URL . $home);
            exit;
        } else {
            header('Location:' . ACCESS_URL . 'logout.php');
            exit;
        }
    }
}

/**
 * Function to get messages from session and format
 * the message as per Bootstrap design standard.
 * If you want any other type of message you can customize accordingly
 * 
 * @package RegistrationSystem
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @access public
 * @category CommonFunction
 * @return string The HTML formatted notification string
 */
if (!function_exists('getAlertMsg')) {
    function getAlertMsg()
    {
        // check if session has been set
        if (isset($_SESSION['STATUS']) and isset($_SESSION['MSG'])) {
            /**
             * if set initialize a variable to store the html formatted string
             * @access private
             * @var string The HTML formatted string
             */
            $formattedMsg       = '';
            if ($_SESSION['STATUS'] === 'error') {
                // if status is error then format with related style and so on
                $formattedMsg   = '<div class="alert alert-danger alert-dismissable">'. $_SESSION['MSG'] .'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
            } elseif ($_SESSION['STATUS'] === 'warning') {
                $formattedMsg   = '<div class="alert alert-danger alert-dismissable">'. $_SESSION['MSG'] .'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
            } else {
                $formattedMsg   = '<div class="alert alert-success alert-dismissable">'. $_SESSION['MSG'] .'<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>';
            }
            // at last unset the seeions set
            unset($_SESSION['STATUS']);
            unset($_SESSION['MSG']);
            // return the formatted string
            return $formattedMsg;
        }
        return false;
    }
}


if (!function_exists('isLogged')) {
    /**
     * function to check if user is logged in or not
     * and to return usertype/privilage
     * 
     * @package JKDiag
     * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
     * @access public
     * @category CommonFunction
     * @return boolean If user is logged in, returns true else false
     */
    function isLogged()
    {
        // check if user credentials has been set and the file to be accessed is correct
        if (isset($_SESSION['USERNAME']) and !empty($_SESSION['USERNAME'])) {
            return $_SESSION['USERTYPE'];
        } else {
            return false;
        }
    }
}

//if (!function_exists('redirectLogged')) {
//    /**
//     * function to check if user is logged in or not
//     * and to redirect to the specific page if so
//     * 
//     * @package JKDiag
//     * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
//     * @access public
//     * @category CommonFunction
//     * @return boolean If user is logged in, returns true else false
//     */
//    function redirectLogged()
//    {
//        die(INSTALL_DIR . '/admin/index.php');
//        // check if user credentials has been set and the file to be accessed is correct
//        if (isset($_SESSION['USERNAME']) and !empty($_SESSION['USERNAME'])) {
//            if ($_SESSION['USERTYPE'] === '1') {
//                header("Location:" . ACCESS_URL . 'admin/dashboard.php');
//            } else {
//                header("Location:" . ACCESS_URL . 'dashboard.php');
//            }
//        } else {
//            header("Location:" . ACCESS_URL . 'index.php');
//        }
//        exit(0);
//    }
//}

if (!function_exists('assignTemplate')) {
    /**
     * function to check if user is logged in or not
     * and to redirect to the specific page if so
     * 
     * @param mixed $replacementArray The associative array to be replaced against defined keys
     * 
     * @package JKDiag
     * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
     * @access public
     * @category CommonFunction
     * @return void prints the data as per passed
     */
    function assignTemplate($replacementArray, $templateFileName = '')
    {
        // require the template for respective user to show the design
        if ($templateFileName === '') {
            if (isLogged() === '1') {
                $template           = DIRPATH . DS . 'helpers' . DS . 'templates' . DS . 'adminTemplate.php';
            } else {
                $template           = DIRPATH . DS . 'helpers' . DS . 'templates' . DS . 'userTemplate.php';
            }
        } else {
            $template           = DIRPATH . DS . 'helpers' . DS . 'templates' . DS . $templateFileName;
        }
        // check if the template exists else give out an error
        if (!file_exists($template)) {
            die('The required template : ' . $template . ' could not be found.');
        }
        // get the template contents
        $templateContents       = file_get_contents($template);
        // assign the path of favicon icon
        $replacementArray['FaviconPath'] = ACCESS_URL . 'helpers/css/images/jk.ico';
        // convert the css files array into a css link string
        if (array_key_exists('CSSHelpers', $replacementArray)) {
            $links              = '';
            if (count($replacementArray['CSSHelpers'])) {
                foreach ($replacementArray['CSSHelpers'] as $key => $value) {
                    $links      .= '<link href="'. ACCESS_URL . 'helpers/css/' . $value .'" rel="stylesheet" type="text/css" media="all">';
                }
            }
            $replacementArray['CSSHelpers'] = $links;
        }
        // convert the js files array into a css link string
        if (array_key_exists('JSHelpers', $replacementArray)) {
            $links              = '';
            foreach ($replacementArray['JSHelpers'] as $key => $value) {
                $links          .= '<script src="'. ACCESS_URL . 'helpers/js/' . $value .'" type="text/javascript"></script>';
            }
            $replacementArray['JSHelpers'] = $links;
        }
        // assign Name of the user
        $replacementArray['UserName'] = $_SESSION['NAME'];
        $replacementArray['AbsUrl'] = ACCESS_URL;
        // assign the template contents into final contents
        $finalContents          = $templateContents;
        foreach ($replacementArray as $key => $value) {
            $finalContents      = preg_replace ( '/{'.$key.'}/', $value, $finalContents);
        }
         //$finalContents         = str_replace($rep, $links, $templateContents)
        // remove whitespaces to compress the contents
        $finalContents          = str_replace(array('  ' ,'   ', '    ', "\r", "\n", "\r\n", "\n\r"), '', $finalContents);
        echo $finalContents;
    }
}
