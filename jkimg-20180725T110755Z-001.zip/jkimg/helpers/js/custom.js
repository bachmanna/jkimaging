/* 
 * Custom JavaScript specific for form
 * functionalities and events are handled specifically
 * for ajaxcontact form
 * 
 * @author Kirti Kumar Nayak
 * @copyright http://codecanyon.net
 * @license http://codecanyon.net
 */
$(document).ready(function() {
    if($('.datepicker').length > 0){
        $('.datepicker').datetimepicker({
            pickTime: false
        });
    }
    if($('.datetimepicker').length > 0){
        $('.datetimepicker').datetimepicker({format:'DD-MM-YYYY hh:mm A'});
    }
    if($('.tip').length > 0){
        $('.tip').tooltip();
    }
    if($('.testchk').length > 0) {
        testChkBxLine();
    }
    /*if ($("#sts").length > 0) {
        $("#sts").children('li').each(function(ind,elem){
            $(this).find('a').click(function(e){
                e.preventDefault();
                var sts = $(this).attr('href'), txt = $(this).text();
                $(this).parent('li').parent('ul').prev('button').html(txt + ' <span class="caret"></span>');
                $('#payst').val(sts);
                updateTotPrice();
            });
        });
    }*/
    if ($('#savePrintPat').length > 0) {
        $('#savePrintPat').click(function(e){
            if ($('#drname').val() === '') {
                alert('Please add / select a doctor name');
                return false;
            }
            setTimeout(function(){window.location = 'patient.php?opt=newPatient';}, 400);
        });
    }
    if($('#discVal').length > 0){
        $('#discVal , #discType').change(function(e){
            calcDiscount();
        });
    }
    if ($('#reportTable').length > 0) {
        $('#reportTable').dataTable({
            processing: true,
            autoWidth: false,
            paging: true,
            columnDefs: [
                { orderable: false, targets: -1 },
                { width: "100px", targets: [-1] }
            ],
            drawCallback:function(settings) {
                if ($('.tip').length > 0) {
                    $('.tip').tooltip();
                }
            },
            ajax: $("#reportTable").attr('data-get-ajax')
            /*"bProcessing": true,
            "bAutoWidth": false,
            "sPaginationType": "full_numbers",
            "bJQueryUI": false,
            "sAjaxSource": $('#reportTable').attr('data-get-ajax'),
            "fnInitComplete": function(oSettings, json) {
                if($('.tip').length > 0){
                    $('.tip').tooltip();
                }
            }*/
        });
        
        /*jQuery.fn.dataTableExt.aTypes.unshift(
            function (sData){
                if (sData !== null && sData.match(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[012])\/(19|20|21)\d\d$/)){
                    return 'date-uk';
                }
                return null;
            }
        );*/
    }
    if ($('#saveDoc').length) {
        $('#saveDoc').click(function(e){
            e.preventDefault();
            $.ajax({
                url: $('#docform').attr('action'),
                type: 'POST',
                data: $('#docform').serialize(),
                dataType: "json",
                beforeSend: function() {
                    $('#saveDoc').attr('disabled', 'disabled');
                    if ($(".alert").length > 0) {
                        $(".alert").each(function(index, element) {
                            $(element).remove();
                        });
                    }
                },
                success: function(data) {
                    if (data.status === 'success') {
                        $('#ErrMsg').html('<div class="alert alert-success alert-dismissable">' + data.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>').fadeIn('slow');
                        $('#docform')[0].reset();
                        $('#saveDoc').removeAttr('disabled');
                        $('#drname').empty().load('respond.php?opt=reloadDrSelectBox')
                    } else {
                        $('#ErrMsg').html('<div class="alert alert-danger alert-dismissable">' + data.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>').fadeIn('slow');
                        $('#saveDoc').removeAttr('disabled');
                    }
                    $('#docModal').modal('hide');
                }
            });
        });
    }
    if ($('.ajaxfrm').length) {
        $('.ajaxfrm').find('button[type="submit"]').click(function(e){
            var btn = $(this);
            e.preventDefault();
            $.ajax({
                url: $('.ajaxfrm').attr('action'),
                type: 'POST',
                data: $('.ajaxfrm').serialize(),
                dataType: "json",
                beforeSend: function() {
                    btn.button('loading');
                    if ($("#ErrMsg.alert").length > 0) {
                        $("#ErrMsg.alert").each(function(index, element) {
                            $(element).remove();
                        });
                    }
                },
                success: function(data) {
                    btn.button('reset');
                    
                    if (data.status === 'success') {
                        $('#ErrMsg').html('<div class="alert alert-success alert-dismissable">' + data.msg + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>').fadeIn('slow');
                        btn.removeClass('btn-primary').addClass('btn-success');
                        btn.html('<i class="fa fa-check"></i> Saved Successfully');
                        $('.ajaxfrm')[0].reset();
                        window.location = data.url;
                    } else {
                        $('#ErrMsg').html('<div class="alert alert-danger alert-dismissable">' + data.msg + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button></div>').fadeIn('slow');
                        btn.removeClass('btn-primary').addClass('btn-danger');
                        btn.html('<i class="fa fa-close"></i> Error !');
                    }
                    setTimeout(function(){
                        btn.removeClass('btn-success btn-danger').addClass('btn-primary');
                        btn.html('<i class="fa fa-save"></i> Save Data');
                    }, 10000);
                }
            });
        });
    }
    if ($('.action').length > 0) {
        $('.action').tooltip();
    }

});
function loadTests(){
    $.ajax({
        url: 'respond.php?opt=loadTests',
        type: 'POST',
        data: {patid: $('#tid').val(), catid: $('#cat').val(), alphabet: $('#alphabets').val()},
        dataType: "html",
        beforeSend: function() {
            $('#testList').html('<i class="fa fa-spinner fa-pulse fa-fw fa-5x"></i><h1>Loading...</h1>');
        },
        success: function(dat) {
            $('#testList').html(dat);
            //testChkBxLine();
            checkSelectedChkBxs();
            if ($('.testchk').length > 0) {
                $('.testchk').each(function (index, element) {
                    $(element).bind('change', function () {
                        testLine(element);
                    });
                });
            }
        }
    });
}
function confirmDelete(elem, e){
    e.preventDefault();
    if(confirm("Are you sure to delete ?")){
        window.location=$(elem).attr('href');
    }else{
        return false;
    }
}
/*function handleTestListAddDelete(tid, option){
    $.ajax({
        url: 'respond.php?opt=chkTst',
        type: 'POST',
        data: {tid: tid, bopt: option},
        dataType: "html",
        success: function(data) {
            var tstid = '', tid = '';
            $('#testcal').html(data);
            if ($('.testLine').length) {
                $('.testLine').each(function (index, element) {
                    $(element).bind('closed.bs.alert', function () {
                        tstid = $(this).attr('id');
                        tid = tstid.split('_');
                        $('#test_'+tid[1]).prop( "checked", false );
                        handleTestListAddDelete(tid[1], 'removeCalc');
                    });
                });
            }
        }
    });
    $('#discVal').blur(function(e){
        e.preventDefault();
        calcDiscount();
    });
}
function loadSubCats(selObj){
    if ($('#scat').length > 0) {
        $.ajax({
            url: 'tests.php?opt=subcatsUnderCat',
            type: 'POST',
            data: {catid: $(selObj).val()},
            dataType: "html",
            success: function(data) {
                $('#scat').empty().html(data);
            }
        });
    }
}
function calcDiscount(){
    var total = parseFloat($('#totVal').val());
    var discVal = parseFloat($('#discVal').val());
    var discType = $('#discType').val();
    var grTot = 0;
    var discountAmt = 0;
    if(discType === 'R') {
        discountAmt = Math.ceil(discVal);
    } else {
        discountAmt = Math.ceil(total * (discVal / 100));
    }
    $('#totDiscVal').val(discountAmt + '.00');
    grTot = Math.ceil(total - discountAmt);
    $('#grTotVal').val(Math.ceil(grTot) + '.00');
}*/
function testChkBxLine() {
    $('.testchk').each(function (index, element) {
        $(element).bind('change', function () {
            testLine(element);
        });
    });
    updateTotPrice();
}
function testLine(obj) {
    var tdata = $(obj).attr('id').split('_'), tstprice = 0;
    if($(obj).prop('checked') === true){
        if ($('selTst_'+tdata[1]).length < 1) {
            var tstoprice = $(obj).attr('data-op-price'),
                tstprice = $(obj).attr('data-ip-price'),
                tstline = '<div class="alert alert-success alert-dismissable testLine" id="selTst_'+tdata[1]
                + '" style="padding:5px;margin:2px"><div class="container"><div class="col-xs-8">'
                + $(obj).attr('data-test-name')+'</div><div class="col-xs-3 text-right">'
                + '<span class="fa fa-rupee"></span>&nbsp;<span class="price">'
                + tstoprice+'.00</span><input type="hidden" name="tstid[]" value="'+tdata[1]+'">'
                + '<input type="hidden" name="tstpr[]" value="'+tstprice+'">'
                + '<input type="hidden" name="tstopr[]" value="'+tstoprice+'"></div><div class="col-xs-1">'
                + '<button type="button" class="close" style="right:0" data-dismiss="alert" aria-hidden="true">'
                + '&times;</button></div></div></div>';

            $('#testcal').append(tstline);
            closeTestLineToUncheck(tdata[1]);
            updateSelectedTestInHiddenFld(tdata[1]);
        }
    } else {
        uncheckToRemoveTest(tdata[1]);
        updateSelectedTestInHiddenFld(tdata[1]);
    }
    updateTotPrice();
}
function updateSelectedTestInHiddenFld(testId) {
    var chkListStr = $('#tid').val(), indexInArr = -1, chkList = [];
    if (chkListStr !== '') {
        chkList = chkListStr.split(',');
    }
    indexInArr = jQuery.inArray(testId, chkList);
    if (indexInArr >= 0) {
        chkList.splice(indexInArr,1);
        $('#tid').val(chkList);
    } else {
        chkList.push(testId);
        $('#tid').val(chkList);
    }
    updateTotPrice();
}
function uncheckToRemoveTest(testId) {
    $('#testcal').find('#selTst_'+testId).remove();
}
function closeTestLineToUncheck(testId) {
    $('#selTst_'+testId).bind('closed.bs.alert', function () {
        $('#test_'+testId).prop("checked", false);
        updateSelectedTestInHiddenFld(testId);
        updateTotPrice();
    });
}

function getSelectedTestsArray() {
    var selTestsArr = [];
    if ($('.testLine').length > 0) {
        $('.testLine').each(function(index, element){
            var id = $(element).attr('id').split('_');
            if (jQuery.inArray(id[1], selTestsArr) !== -1) {
                selTestsArr.push(id[1]);
            }
        });
    }
    return selTestsArr;
}
function checkSelectedChkBxs() {
    var selectedTests = $('#tid').val(), i = 0;
    if (selectedTests === '') {
        return false;
    } else {
        selectedTests = selectedTests.split(',');
    }
    for (i = 0; i < selectedTests.length; ++i) {
        if (selectedTests[i] !== '') {
            $('#test_'+selectedTests[i]).prop('checked', true);
        }
    }
}
function updateTotPrice(){
    var totPrice = 0, calcHtml = '',
            totNos = $('.testLine').length,
            discnt = parseFloat(($('#disc').val() === '') ? 0 : $('#disc').val()),
            crdt = parseFloat(($('#credval').val() === '') ? 0 : $('#credval').val()),
            cardamt = parseFloat(($('#cardamt').val() === '') ? 0 : $('#cardamt').val()),
            grtot = 0, paid = 0, paidstr = '';
    if (totNos > 0) {
        $('.testLine').each(function(index, element) {
            totPrice += parseFloat($(element).find('.price').text());
        });
    }
    grtot = (totPrice - discnt);
    paid = (grtot - crdt);
    paidstr = '<i class=fa fa-inr"></i> ' + totPrice + ((discnt > 0) ? (' - ' + discnt + ' D') : '') 
            + ((crdt > 0) ? (' - ' + crdt + ' Cr.') : '') + ((cardamt > 0) || ((paid - cardamt) > 0) ? ' = ' : '')
            + ((cardamt > 0) ? ('<i class="fa fa-credit-card"></i> ' + cardamt) : '')
            + ((cardamt !== paid) ? ((cardamt > 0) ? (' + <i class="fa fa-money"></i> ' + (paid - cardamt)) : ('<i class="fa fa-money"></i> ' +(paid - cardamt))) : '')
            + ' = ';
    calcHtml = '<div class="alert alert-info" id="sumTot'
                + '" style="padding:5px;margin:2px"><div class="container"><div class="col-xs-8">'
                + 'Total ' + totNos + ' Tests</div><div class="col-xs-3 text-right">'
                + '<span class="fa fa-rupee"></span>&nbsp;<span class="totprice">'
                + totPrice+'.00'
                + '</span></div><div class="col-xs-1"></div></div></div>';
    $('#testtotsdiscs').html(calcHtml);
    $('#totpr').val(totPrice);
    $('#grtot').val(grtot);
    $('#paidstr').html(paidstr);
    $('#paid').val(paid);
}