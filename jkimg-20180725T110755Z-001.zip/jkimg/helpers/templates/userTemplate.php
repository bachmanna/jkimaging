<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Dashboard for JK Imaging">
        <meta name="author" content="Kirti Kumar Nayak <admin@thebestfreelancer.in@gmail.com>">
        <link rel="shortcut icon" href="{FaviconPath}">

        <title>{PageTitle}</title>
        {CSSHelpers}
    </head>

    <body>

        <!-- Fixed navbar -->
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="Javascript:void(0);">JK Imaging</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                        <li><a href="patient.php?opt=newPatient">New Patient</a></li>
                        
                        <li><a href="tests.php"><i class="fa fa-eyedropper"></i> All Tests</a></li>
                        
                        <li><a href="income.php?opt=oneDay"><span class="fa fa-rupee"></span> Income</a></li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-wrench"></i> Settings <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="index.php?opt=viewProfile">View Profile</a></li>
                                <li><a href="index.php?opt=editProfile">Edit Profile</a></li>
                                <li class="divider"></li>
                                <li><a href="../logout.php">Logout</a></li>
                            </ul>
                        </li>
                        <li class="active"><a href="Javascript:void(0);">Hi {UserName}</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>

        <div class="container top-menu-fixed">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="ErrMsg">
                    {ErrorMessages}
                </div>
                {CenterContents}
            </div>
        </div> <!-- /container -->
        {JSHelpers}
    </body>
</html>
