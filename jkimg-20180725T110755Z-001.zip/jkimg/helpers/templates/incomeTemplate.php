<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Dashboard for JK Imaging">
        <meta name="author" content="Kirti Kumar Nayak<kirtikumar.software@gmail.com>">
        <link rel="shortcut icon" href="{FaviconPath}">

        <title>{PageTitle}</title>
        {CSSHelpers}
    </head>

    <body>
        <div class="container">
            <div class="row">
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top: 150px">
                    
                    <h2 class="panel-title text-center">Income Details</h2>
                    {CenterContents}
                    
                </div>
            </div>
        </div> <!-- /container -->
        {JSHelpers}
    </body>
</html>