<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Dashboard for JK Imaging">
        <meta name="author" content="Kirti Kumar Nayak <admin@thebestfreelancer.in>">
        <link rel="shortcut icon" href="{FaviconPath}">

        <title>{PageTitle}</title>
        {CSSHelpers}
    </head>

    <body>
        <div class="navbar navbar-inverse navbar-fixed-top hidden-print" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="Javascript:void(0);">JK Imaging</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                        <li class="dropdown">
                            <a href="Javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-registered"></i> Patient <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="patient.php?opt=newPatient">New Patient</a></li>
                                <li class="divider"></li>
                                <li><a href="index.php?opt=all">View All Patients</a></li>
                                <li class="divider"></li>
                                <li class="dropdown-header">Categorized Patients</li>
                                <li><a href="index.php">Today&#39;s Patients</a></li>
                                <li><a href="index.php?opt=anotherDate">Another Date&#39;s Patients</a></li>
                                <li><a href="index.php?opt=rangeDate">Patients in a date range</a></li>
                                <li class="divider"></li>
                                <li><a href="index.php?opt=personal">Patients by you</a></li>
                            </ul>
                        </li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-eyedropper"></i> Tests <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="tests.php?opt=add">Add Test</a></li>
                                <li><a href="tests.php">View All Tests</a></li>
                            </ul>
                        </li>
                        
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-stethoscope"></i> Doctor <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="doctor.php?opt=add">Add Doctor</a></li>
                                <li><a href="doctor.php?opt=all">View All Doctors</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-rupee"></span> Income <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="income.php?opt=oneDay">Today&#39;s Income</a></li>
                                <li><a href="income.php">Today&#39;s Income by You</a></li>
                                <li class="divider"></li>
                                <li><a href="income.php?opt=doctorToday">Income via Doctors&#39; Today</a></li>
                                <li><a href="income.php?opt=doctorSdate">Doctors&#39; Income Specific Date</a></li>
                                <li><a href="income.php?opt=doctorDt2Dt">Doctors&#39; Income Specific Date range</a></li>
                                <li class="divider"></li>
                                <li><a href="income.php?opt=sdate">Income in a Specific Date</a></li>
                                <li><a href="income.php?opt=dt2dt">Income in Specific Date range</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-users"></i> Employees <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="employee.php?opt=add">Add Employee</a></li>
                                <li><a href="employee.php?opt=all">View All Employees</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-database"></i> Stock <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="stock.php?opt=item">Items</a></li>
                                <li><a href="stock.php?opt=itemlog">Log Book</a></li>
                                <li><a href="stock.php?opt=usage">Log Usage</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-wrench"></i> Settings <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="index.php?opt=viewProfile">View Profile</a></li>
                                <li><a href="index.php?opt=editProfile">Edit Profile</a></li>
                                <li class="divider"></li>
                                <li><a href="../logout.php">Logout</a></li>
                            </ul>
                        </li>
                        <li class="active"><a href="Javascript:void(0);">Hi {UserName}</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>
        <div class="container-fluid hidden-print" style="margin-bottom: 70px"></div>
        <div class="container" id="docPrintPage">
            <div class="row">
                
                            {CenterContents}
                    
            </div>
            <div class="row text-center hidden-print">
                <button class="btn btn-lg btn-danger" onclick="javascript:window.print();"><i class="fa fa-print"></i> Print</button>
            </div>
        </div> <!-- /container -->
        {JSHelpers}
    </body>
</html>
