<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Dashboard for JK Imaging">
        <meta name="author" content="Kirti Kumar Nayak <admin@thebestfreelancer.in>">
        <link rel="shortcut icon" href="{FaviconPath}">

        <title>{PageTitle}</title>
        {CSSHelpers}
        <style type="text/css" media="all">
            
        </style>
    </head>

    <body>
        <div class="container">
            <div class="row" id="printPage">
                <div class="col-xs-12">
                    <table border="0" style="width:100%">
                        <tr>
                            <td style="width:50px">
                                <img src="{AbsUrl}helpers/css/images/logo.jpg" alt="JK Imaging" class="img-responsive">
                            </td>
                            <td style="text-align: left;vertical-align: middle;padding-left: 10px">
                                <h1 style="color: #7a0202;font-weight: 700;margin: 5px 0">JK Imaging</h1>
                                <em>Trinity Neuro &amp; Trauma Hospital, 304, Bhoi Nagar, Behind DCP Office, Vani Vihar, Bhubaneswar - 7</em>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title text-center">Money Receipt</h3> {RcptNo}
                        </div>
                        {CenterContents}
                        <div class="panel-footer" style="padding-top: 50px">
						<table style="width:100%;border:0" border="0">
						<tr>
						<th class="text-left">Contact : 9090368068</th>
						<td class="text-right">Billing Executive<br/>{EnteredBy}</td>
						</tr>
						</table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 text-center hidden-print">
                <button type="button" name="print" id="print" class="btn btn-danger" onclick="javascript:window.print();"><i class="fa fa-print"></i> Print</button>
                &nbsp;
                <a href="patient.php?opt=newPatient" class="btn btn-warning"><i class="fa fa-arrow-circle-left"></i> Back</a>
            </div>
        </div> <!-- /container -->
        {JSHelpers}
    </body>
</html>
