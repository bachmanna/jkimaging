<?php
/**
 * This is the logout users script to log out users
 * 
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @license http://thebestfreelancer.in The Best Freelancer. India
 * @version Build 1.0
 * @package JKDiag
 * @copyright (c) 2014, The Best Freelancer
 * @outputBuffering disabled
 */

require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';

session_destroy();
@session_start();

$_SESSION['STATUS']     = 'success';
$_SESSION['MSG']        = 'You have logged out';
session_write_close();
header("Location:" . ACCESS_URL);
exit;