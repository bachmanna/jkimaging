<?php
// common include file required
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
// throw out the user if it is not admin
if (isLogged() !== '3'){redirectUser();}
// extract get data to get option by user
$opt = DataFilter::getObject()->cleanData($_GET);

if (isset($opt['opt']) and ! empty($opt['opt'])) {
    switch ($opt['opt']) {

        case 'oneDayInc':
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">View all income in <?php echo date('d/m/Y', strtotime($dtRep)); ?></div>
                    <table cellpadding="0" cellspacing="0" border="0" class="table table-bordered table-hover center table-squeezed">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Patient Name</th>
                                <th>Bill No.</th>
                                <th>Consultant</th>
                                <th>Tests</th>
                                <th>Bill Amt.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = 'select pname, ptc_pat_id, ptc_hosp_pid, ptc_hosp_billno, ptc_hosp_dttm,'
                                . ' ptc_hosp_pattype, dr_name, dr_org, ptc_tot_price, ptc_discount, ptc_credit'
                                . ' from patient_test_calculations left join patient_data on ptc_pat_id = pid '
                                . ' left join doctor_details on dr_id = ptc_dr_id '
                                . ' where date(ptc_hosp_dttm) = ? and ptc_hosp_pattype = ?';
                            $opdata = DbOperations::getObject()->fetchData($sql, [$dtRep, 'OP']);
                            $ipdata = DbOperations::getObject()->fetchData($sql, [$dtRep, 'IP']);
                            $sql = 'select cat_name, test_name, pt_oprice, pt_price from patient_tests'
                                . ' left join test_list on test_id = pt_test_id '
                                . ' left join test_cats on cat_id = under_cat '
                                . ' where pat_id = ?';
                            $tres = DbOperations::getObject()->prepareQuery($sql);
                            $opSerRes = DbOperations::getObject()->prepareQuery('select count(ptc_pat_id) as totpatcount from patient_test_calculations where ptc_hosp_pattype = ? and ptc_id < ?');
                            $counter = 0;
                            $grCount = 0;
                            $grtot = 0;
                            $grcr = 0;
                            $grdisc = 0;
                            echo '<tr><th colspan="6" class="text-center"><h4 style="margin:0 auto">Out Patient</h4></th></tr>';
                            foreach ($opdata as $pd) {
                                $opSerNo = DbOperations::getObject()->fetchData('', ['OP', $pd['ptc_pat_id']], false, $opSerRes);
                                $rcptNo = (intval($opSerNo[0]['totpatcount'])+1);
                                $patType = 'OP-';
                                switch (strlen($rcptNo)) {
                                    case 1:
                                        $rcptNo = '000' . $rcptNo;
                                        break;
                                    case 2:
                                        $rcptNo = '00' . $rcptNo;
                                        break;
                                    case 3:
                                        $rcptNo = '0' . $rcptNo;
                                        break;
                                    default :
                                        break;
                                }
                                $rcptNo = $patType . $rcptNo;
                            ?>
                            <tr>
                                <td><?php echo ++$counter;++$grCount; ?></td>
                                <td><?php echo $pd['pname']; ?></td>
                                <td><?php echo $rcptNo; ?></td>
                                <td><?php echo $pd['dr_name'] . ', ' . $pd['dr_org']; ?></td>
                                <td><?php
                                    $tstdat = DbOperations::getObject()->fetchData('', [$pd['ptc_pat_id']], false, $tres);
                                    foreach ($tstdat as $tst) {
                                        $grtot += floatval($tst['pt_oprice']);
                                        echo $tst['cat_name'] . ' - ' . $tst['test_name'] . ' : <i class="fa fa-inr"></i> ' . $tst['pt_oprice'] . '<br/>';
                                    }
                                ?></td>
                                <td class="text-right"><?php
                                echo '<i class="fa fa-inr"></i> ' . (floatval($pd['ptc_tot_price']) - (floatval($pd['ptc_discount']) + floatval($pd['ptc_credit'])));
                                echo '<br/>';
                                if ($pd['ptc_discount'] !== '0') {
                                    echo '<small>Discount <i class="fa fa-inr"></i> ' . $pd['ptc_discount'] . ', </small>';
                                    $grdisc += floatval($pd['ptc_discount']);
                                }
                                if ($pd['ptc_credit'] !== '0') {
                                    echo '<small>Cr.<i class="fa fa-inr"></i> ' . $pd['ptc_credit'] . '</small>';
                                    $grcr += floatval($pd['ptc_credit']);
                                }
                                ?></td>
                            </tr>
                            <?php } ?>
                            <tr class="bg-warning">
                                <th class="text-right" colspan="3">Number of Out Patients : <?php echo $grCount; $totOpCount = $grCount;?></th>
                                <th class="text-right">Total (Total - (Tot.Discount + Tot.Credit)) :</th>
                                <th class="text-right">
                                    <?php echo number_format($grtot, 2, '.', ',');$optot = $grtot; ?> - 
                                    (<?php echo number_format($grdisc, 2, '.', ',');$opdisc = $grdisc; ?> + 
                                    <?php echo number_format($grcr, 2, '.', ',');$opcr = $grcr; ?>)
                                </th>
                                <th class="text-right">
                                    <i class="fa fa-inr"></i> <?php echo number_format(($grtot-($grdisc+$grcr)), 2, '.', ','); ?>
                                </th>
                            </tr>
                            <?php
                            $counter = 0;
                            echo '<tr><th colspan="6" class="text-center"><h4 style="margin:0 auto">Indoor Patient</h4></th></tr>';
                            foreach ($ipdata as $pd) {
                                $rcptNo = $pd['ptc_pat_id'];
                                $patType = 'IP-';
                                switch (strlen($rcptNo)) {
                                    case 1:
                                        $rcptNo = '000' . $rcptNo;
                                        break;
                                    case 2:
                                        $rcptNo = '00' . $rcptNo;
                                        break;
                                    case 3:
                                        $rcptNo = '0' . $rcptNo;
                                        break;
                                    default :
                                        break;
                                }
                                $rcptNo = $patType . $rcptNo;
                            ?>
                            <tr>
                                <td><?php echo ++$counter;++$grCount; ?></td>
                                <td><?php echo $pd['pname']; ?></td>
                                <td><?php echo $rcptNo; ?></td>
                                <td><?php echo $pd['dr_name'] . ', ' . $pd['dr_org']; ?></td>
                                <td><?php
                                    $tstdat = DbOperations::getObject()->fetchData('', [$pd['ptc_pat_id']], false, $tres);
                                    foreach ($tstdat as $tst) {
                                        $grtot += floatval($tst['pt_oprice']);
                                        echo $tst['cat_name'] . ' - ' . $tst['test_name'] . ' : <i class="fa fa-inr"></i> ' . $tst['pt_oprice'] . '<br/>';
                                    }
                                ?></td>
                                <td class="text-right"><?php
                                echo '<i class="fa fa-inr"></i> ' . (floatval($pd['ptc_tot_price']) - (floatval($pd['ptc_discount']) + floatval($pd['ptc_credit'])));
                                echo '<br/>';
                                if ($pd['ptc_discount'] !== '0') {
                                    echo '<small>Discount <i class="fa fa-inr"></i> ' . $pd['ptc_discount'] . ', </small>';
                                    $grdisc += floatval($pd['ptc_discount']);
                                }
                                if ($pd['ptc_credit'] !== '0') {
                                    echo '<small>Cr.<i class="fa fa-inr"></i> ' . $pd['ptc_credit'] . '</small>';
                                    $grcr += floatval($pd['ptc_credit']);
                                }
                                ?></td>
                            </tr>
                            <?php
                            }
                            ?>
                            <tr class="bg-warning">
                                <th class="text-right" colspan="3">Number of Indoor Patients : <?php echo $grCount-$totOpCount;?></th>
                                <th class="text-right">Total (Total - (Tot.Discount + Tot.Credit)) :</th>
                                <th class="text-right">
                                    <?php echo number_format(($grtot-$optot), 2, '.', ','); ?> - 
                                    (<?php echo number_format(($grdisc-$opdisc), 2, '.', ','); ?> + 
                                    <?php echo number_format(($grcr-$opcr), 2, '.', ','); ?>)
                                </th>
                                <th class="text-right">
                                    <i class="fa fa-inr"></i> <?php echo number_format((($grtot-$optot)-(($grdisc-$opdisc)+($grcr-$opcr))), 2, '.', ','); ?>
                                </th>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="bg-info">
                                <th class="text-right" colspan="3">Total Number of Patients : <?php echo $grCount;?></th>
                                <th class="text-right">Grand Total (Total - (Tot.Discount + Tot.Credit)) :</th>
                                <th class="text-right">
                                    <?php echo number_format($grtot, 2, '.', ','); ?> - (<?php echo number_format($grdisc, 2, '.', ','); ?> + <?php echo number_format($grcr, 2, '.', ','); ?>)
                                </th>
                                <th class="text-right">
                                    <i class="fa fa-inr"></i> <?php echo number_format(($grtot-($grdisc+$grcr)), 2, '.', ','); ?>
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <?php
            $pageTitle = 'View all income in one day - JK Imaging User Dashboard';
            break;
        case 'oneDay':
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">View all income one day</div>
                    <div class="panel-body">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                            <thead>
                                <tr>
                                    <th>Test Category</th>
                                    <th>Number of Tests</th>
                                    <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                                $catData = DbOperations::getObject()->fetchData($sql);
                                $grTotTst = 0;
                                $grTotPrice = 0;
                                $tsql = 'select count(pt_id) as no_of_tests, sum(pt_oprice) as tot_rs'
                                    . ' from patient_tests left join test_list on pt_test_id = test_id'
                                    . ' where under_cat = ? and date(pt_dttm) = ? and pt_status = ?';
                                $tres = DbOperations::getObject()->prepareQuery($tsql);
                                foreach ($catData as $cats) {
                                    $incDat = DbOperations::getObject()->fetchData('', [$cats['cat_id'], $dtRep, 1], false, $tres);
                                    $grTotTst += intval($incDat[0]['no_of_tests']);
                                    $grTotPrice += floatval($incDat[0]['tot_rs']);
                                    ?>
                                    <tr>
                                        <td><?php echo $cats['cat_name']; ?></td>
                                        <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                        <td class="text-right"><span class="fa fa-rupee"></span>&nbsp;<?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                                    </tr>
                                    <?php
                                }
                                $psql = 'select'
                                    . ' sum(ptc_tot_price) as sum_total_price,'
                                    . ' sum(ptc_discount) as sum_total_discount,'
                                    . ' sum(ptc_credit) as sum_total_credit,'
                                    . ' sum(ptc_card_amt) as sum_total_card'
                                    . ' from patient_test_calculations where'
                                    . ' date(ptc_hosp_dttm) = ? and ptc_status = ?';
                                $totDat = DbOperations::getObject()->fetchData($psql, [$dtRep, 1]);
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="text-right">Sum Totals :</th>
                                    <th class="text-right"><?php print($grTotTst); ?></th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Discount :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Credit :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_credit']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Payment Modes :</th>
                                    <th class="text-right">
                                        
                                        <?php
                                        $totAmt = (floatval($grTotPrice) - (floatval($totDat[0]['sum_total_discount'])+floatval($totDat[0]['sum_total_credit'])));
                                        echo '<i class="fa fa-credit-card"></i> <span class="fa fa-rupee"></span>&nbsp;' . number_format(floatval($totDat[0]['sum_total_card']), 2, '.', ','); 
                                        echo ' + <i class="fa fa-money"></i> <span class="fa fa-rupee"></span>&nbsp;' . number_format(($totAmt - floatval($totDat[0]['sum_total_card'])), 2, '.', ','); 
                                        ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Grand Total Income :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format((floatval($grTotPrice) - (floatval($totDat[0]['sum_total_discount'])+floatval($totDat[0]['sum_total_credit']))), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <?php if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                                    <tr>
                                        <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                                    </tr>
                                <?php } ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'View all income in one day - JK Imaging User Dashboard';
            break;

        case 'sdate':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Select a date to view income details</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="anotherpatform" name="anotherpatform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=oneDayInc">
                            <div class="form-group">
                                <label for="dt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="dt" name="dt" required="required" autocomplete="off" placeholder="Date to show">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date to view the income - JK Imaging Admin Panel';
            break;


        case 'dt2dt':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Select a date range to view income details</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="daterangeinc" name="daterangeinc" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=dateRange">
                            <div class="form-group">
                                <label for="sdt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Start Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="sdt" name="sdt" required="required" autocomplete="off" placeholder="Date to start">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="edt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">End Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="edt" name="edt" required="required" autocomplete="off" placeholder="Date to end">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date range to view the income - JK Imaging Admin Panel';
            break;

        case 'dateRange':

            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['sdt']) or ($submittedData['sdt'] === '') or ! isset($submittedData['edt']) or ($submittedData['edt'] === '')) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must enter a date range';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            $sdt = strtotime($submittedData['sdt']);
            $edt = strtotime($submittedData['edt']);
            ob_start();
            ?>

            <p class="text-center">
                The Income Details between Dt.<?php echo date('d-m-Y', $sdt); ?> and <?php echo date('d-m-Y', $edt); ?>
                &nbsp;(All Figures in <i class="fa fa-rupee"></i>)
            </p>
            <table class="table table-striped table-bordered table-squeezed center">
                <thead>
                    <tr>
                        <td>Date</td>
                        <?php
                        $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                        $catData = DbOperations::getObject()->fetchData($sql);
                        $grTstPrice = [];
                        foreach ($catData as $cats) {
                            if (!isset($grTstPrice[$cats['cat_id']])) {
                                // to save category wise price
                                $grTstPrice[$cats['cat_id']] = 0;
                            }
                            ?>
                            <td><?php echo $cats['cat_name'] ?></td>
                        <?php } ?>
                        <td>Sum
                        <td>Tot. Discount</td>
                        <td>Gr. Tot.</td>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    // to traverse through date
                    $dttm = $sdt;
                    // to store grand total discount
                    $grTotDisc = 0;
                    $grTotCr = 0;
                    // to save full final grand total
                    $grTotFinalPrice = 0;

                    // to save error income dates
                    $errDates = [];
                    $tsql = 'select sum(pt_oprice) as tot_rs from patient_tests left join test_list'
                        . ' on pt_test_id = test_id where under_cat = ? and pt_status = ? and date(pt_dttm) = ?';
                    $tres = DbOperations::getObject()->prepareQuery($tsql);
                    $psql = 'select sum(ptc_tot_price) as sum_total_price, sum(ptc_credit) as sum_total_credit, '
                        . ' sum(ptc_discount) as sum_total_discount from patient_test_calculations'
                        . ' where date(ptc_dttm) = ? and ptc_status = ?';
                    $pres = DbOperations::getObject()->prepareQuery($psql);
                    while ($dttm < $edt) {
                        ?>
                        <tr>
                            <td><?php echo date('d/m/y', $dttm); ?></td>
                            <?php
                            $grTotPrice = 0;
                            foreach ($catData as $cats) {
                                $incDat = DbOperations::getObject()->fetchData('', [$cats['cat_id'], 1, date('Y-m-d', $dttm)], false, $tres);
                                $grTotPrice += floatval($incDat[0]['tot_rs']);
                                $grTstPrice[$cats['cat_id']] += floatval($incDat[0]['tot_rs']);
                                $grTotFinalPrice += floatval($incDat[0]['tot_rs']);
                                ?>
                                <td class="text-right"><?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                            <?php } ?>
                            <td class="text-right"><?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?></td>
                            <?php
                            $totDat = DbOperations::getObject()->fetchData('', [date('Y-m-d', $dttm), 1], false, $pres);
                            $grTotDisc += floatval($totDat[0]['sum_total_discount']);
                            $grTotCr += floatval($totDat[0]['sum_total_credit']);
                            if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) {
                                array_push($errDates, date('d-m-Y', $dttm));
                            }
                            ?>
                            <td class="text-right"><?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?></td>
                            <td class="text-right">
                                <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                            </td>
                        </tr>
                        <?php
                        $dttm += 24 * 60 * 60; //exit;
                    }
                    ?>

                </tbody>
                <tfoot>
                    <tr>
                        <th>Gr. Totals :</th>
                        <?php foreach ($grTstPrice as $catId => $catInc) { ?>
                            <th class="text-right">
                                <?php echo number_format(floatval($catInc), 2, '.', ','); ?>
                            </th>
                        <?php } ?>
                        <th class="text-right">
                            <?php echo number_format(floatval($grTotFinalPrice), 2, '.', ','); ?>
                        </th>
                        <th class="text-right">
                            <?php echo number_format(floatval($grTotDisc), 2, '.', ','); ?>
                        </th>
                        <th class="text-right">
                            <?php echo number_format((floatval($grTotFinalPrice) - floatval($grTotDisc)), 2, '.', ','); ?>
                        </th>
                    </tr>
                    <?php if (count($errDates) > 0) { ?>
                        <tr>
                            <th class="text-center text-danger" colspan="<?php print(count($grTstPrice) + 4); ?>">
                                The income data mismatches, there seems an error in entry in dates: <?php echo implode(', ', $errDates); ?>. Did you edit some tests after date of entry ?
                            </th>
                        </tr>
                    <?php } ?>
                </tfoot>
            </table>

            <?php
            // get contents from buffer
            $contents = ob_get_contents();
            // clean and end the buffer
            ob_end_clean();

            $replacementArray = array(
                'PageTitle' => 'Income Details Between two date range - JK Imaging',
                'CenterContents' => $contents,
                'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
                'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
            );

            assignTemplate($replacementArray, 'incomeTemplate.php');
            exit(0);
            break;

        case 'doctorToday':

            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            $sql = 'select distinct(ptc_dr_id) as drid, dr_name, dr_org '
                . 'from patient_test_calculations left join doctor_details '
                . 'on dr_id = ptc_dr_id where ptc_status = ? and date(ptc_hosp_dttm) = ?';
            $drDat = DbOperations::getObject()->fetchData($sql, [1, $dtRep]);
            if (count($drDat) < 1) {
                echo('<h1>No doctor data to show</h1>');
            }
            $patSql = 'select distinct(ptc_pat_id) as patid,'
                . ' pname from patient_data left join patient_test_calculations'
                . ' on ptc_pat_id = pid where ptc_dr_id = ?'
                . ' and ptc_status = ? and date(ptc_hosp_dttm) = ?';//var_dump($patSql);
            $patRes = DbOperations::getObject()->prepareQuery($patSql);
            $discSql = 'select sum(ptc_discount) as totdisc, sum(ptc_credit) as totcr'
                . ' from patient_test_calculations where ptc_pat_id = ?'
                . ' and date(ptc_hosp_dttm) = ? and ptc_dr_id = ?  and ptc_status = ?';
            $discRes = DbOperations::getObject()->prepareQuery($discSql);
            $ptestsql = 'select test_name, pt_oprice, pt_status, staff_name, ptc_hosp_pid, ptc_hosp_billno, ptc_hosp_pattype'
                . ' from test_list left join patient_tests on pt_test_id = test_id'
                . ' left join staff_users on pt_created_by = staff_id'
                . ' left join patient_test_calculations on ptc_pat_id = pat_id '
                . ' where pat_id = ? and ptc_status = ?'
                . ' and ptc_dr_id = ? and date(pt_dttm) = date(ptc_hosp_dttm)'
                . ' and date(pt_dttm) = ?';
            $ptestRes = DbOperations::getObject()->prepareQuery($ptestsql);
            $opSerRes = DbOperations::getObject()->prepareQuery('select count(ptc_pat_id) as totpatcount from patient_test_calculations where ptc_hosp_pattype = ? and ptc_id < ?');
            $grTotInc = 0;
            $grTotDisc = 0;
            $totCr = 0;
            foreach ($drDat as $dr) {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default" style="margin-bottom: 5px">
                        <div class="panel-heading text-center" style="padding: 2px;font-weight: 700">
                            Dr. <?php echo $dr['dr_name']; ?>
                            <?php echo ($dr['dr_org'] !== '' ? ' (' . $dr['dr_org'] . ')' : ''); ?>
                        </div>

                        <?php
                        $drTot = 0;
                        $drTotDisc = 0;
                        $drTotCr = 0;
                        $patData = DbOperations::getObject()->fetchData('', [$dr['drid'], 1, $dtRep], false, $patRes);
                        //var_dump($patData);
                        $patCount = 0;
                        foreach ($patData as $pat) {
                            $priceDisc = DbOperations::getObject()->fetchData('', [$pat['patid'], $dtRep, $dr['drid'], 1], false, $discRes);
                            $drTotDisc += floatval($priceDisc[0]['totdisc']);
                            $grTotDisc += floatval($priceDisc[0]['totdisc']);
                            $drTotCr += floatval($priceDisc[0]['totcr']);
                            $totCr += floatval($priceDisc[0]['totcr']);
                            ?>
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-squeezed">
                                <caption><?php echo $pat['pname']; ?></caption>
                                <thead>
                                    <tr>
                                        <th class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            Tests Done
                                        </th>
                                        <th class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
                                            By
                                        </th>
                                        <th class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
                                            Bill No.
                                        </th>
                                        <th class="col-lg-3 col-md-3 col-sm-3 col-xs-3 text-right">
                                            Price
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totPrice = 0;
                                    //die($ptestsql);
                                    $ptTestDat = DbOperations::getObject()->fetchData('', [$pat['patid'], 1, $dr['drid'], $dtRep], false, $ptestRes);
                                    foreach ($ptTestDat as $tstDat) {
                                        if ($tstDat['ptc_hosp_pattype'] === 'OP') {
                                            $opSerNo = DbOperations::getObject()->fetchData('', ['OP', $pat['patid']], false, $opSerRes);
                                            $rcptNo = (intval($opSerNo[0]['totpatcount'])+1);
                                            $patType = 'OP-';
                                        } else {
                                            $rcptNo = $pat['patid'];
                                            $patType = 'IP-';
                                        }
                                        switch (strlen($rcptNo)) {
                                            case 1:
                                                $rcptNo = '000' . $rcptNo;
                                                break;
                                            case 2:
                                                $rcptNo = '00' . $rcptNo;
                                                break;
                                            case 3:
                                                $rcptNo = '0' . $rcptNo;
                                                break;
                                            default :
                                                break;
                                        }
                                        $rcptNo = $patType . $rcptNo;
                                        $totPrice += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_oprice']));
                                        $grTotInc += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_oprice']));
                                        $drTot += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_oprice']));
                                        ?>
                                        <tr>
                                            <td><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">' . $tstDat['test_name'] . '</i>' : $tstDat['test_name']); ?></td>
                                            <td>
                                                <?php
                                                $pieces = explode(' ', $tstDat['staff_name']);
                                                if (count($pieces) > 1) {
                                                    echo substr($pieces[0], 0, 1) . '.' . substr($pieces[1], 0, 1);
                                                } else {
                                                    echo substr($pieces[0], 0, 3);
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo $rcptNo;?></td>
                                            <td class="text-right"><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">N/A</i>' : number_format(floatval($tstDat['pt_oprice']), 2, '.', ',')); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="2">Grand total price (Total &hyphen; Discount) from patient</th>
                                        <td class="text-right" colspan="2">
                                            (<?php echo number_format(floatval($totPrice), 2, '.', ','); ?>
                                            -
                                            <?php echo number_format(floatval($priceDisc[0]['totdisc']), 2, '.', ','); ?>
                                            &equals;)&nbsp;
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <strong><?php echo number_format((floatval($totPrice) - floatval($priceDisc[0]['totdisc'])), 2, '.', ','); ?></strong>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php } ?>

                    </div>
                </div>
            <?php } if (intval($grTotInc) > 0) { ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center" style="padding:2px">Total Income on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?></div>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-squeezed center">
                            <tbody>
                                <tr>
                                    <td>Grand total income by all</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotInc), 2, '.', ','); ?></td>
                                </tr>
                                <tr>
                                    <td>Grand total discount</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotDisc), 2, '.', ','); ?></td>
                                </tr>
                                <tr>
                                    <td>Grand total credit</td>
                                    <td class="text-right"><?php echo number_format(floatval($totCr), 2, '.', ','); ?></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-light">
                                    <td>Grand Income</td>
                                    <td class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format((floatval($grTotInc) - (floatval($grTotDisc)-floatval($totCr))), 2, '.', ','); ?>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <?php
            }
            $sqlDoc = 'select dr_name, dr_org, dr_phone,'
                . ' staff_name, dr_created '
                . 'from doctor_details, staff_users'
                . ' where date(dr_created) = ?'
                . ' and dr_created_by = staff_id';
            $docDat = DbOperations::getObject()->fetchData($sqlDoc, [$dtRep]);
            if (count($docDat) > 0) {
                $cnt = 0;
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center" style="padding:2px">New Doctor Added on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?></div>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-squeezed">
                            <thead>
                                <tr>
                                    <th>Sl.</th>
                                    <th>Name</th>
                                    <th>Org./Deptt./Area</th>
                                    <th>Contact</th>
                                    <th>Entered By</th>
                                    <th>Create Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($docDat as $doc) { ?>
                                    <tr>
                                        <td><?php print( ++$cnt); ?></td>
                                        <td><?php echo $doc['dr_name'] ?></td>
                                        <td><?php echo $doc['dr_org'] ?></td>
                                        <td><?php echo $doc['dr_phone'] ?></td>
                                        <td><?php echo $doc['staff_name'] ?></td>
                                        <td><?php echo date('h:i:s A', strtotime($doc['dr_created'])); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php
            }
            // get contents from buffer
            $contents = ob_get_contents();
            // clean and end the buffer
            ob_end_clean();

            $replacementArray = array(
                'PageTitle' => 'Income Details of doctor in a specific day - JK Imaging',
                'CenterContents' => $contents,
                'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
                'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
            );

            assignTemplate($replacementArray, 'doctorIncomeTemplate.php');
            exit(0);
            break;

        case 'doctorSdate':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Select a date to view income details via doctors</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="docIncform" name="docIncform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=doctorToday">
                            <div class="form-group">
                                <label for="dt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="dt" name="dt" required="required" autocomplete="off" placeholder="Date to show">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date to view the income via doctor - JK Imaging Admin Panel';
            break;

        case 'doctorDt2Dt':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Select a date range to view income details via doctors</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="daterangeinc" name="daterangeinc" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=docdateRange">
                            <div class="form-group">
                                <label for="sdt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Start Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="sdt" name="sdt" required="required" autocomplete="off" placeholder="Date to start">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="edt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">End Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="edt" name="edt" required="required" autocomplete="off" placeholder="Date to end">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date range to view the income via doctor - JK Imaging Admin Panel';
            break;

        case 'docdateRange':
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['sdt']) or ( $submittedData['sdt'] === '') or ! isset($submittedData['edt']) or ( $submittedData['edt'] === '')) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must enter a date range';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            $sdt = strtotime($submittedData['sdt']);
            $edt = strtotime($submittedData['edt']);
            ob_start();
            $sql = 'select distinct(ptc_dr_id) as drid, dr_name from patient_test_calculations, doctor_details where dr_id = ptc_dr_id and date(ptc_dttm) between "' . date('Y-m-d', $sdt) . '" and "' . date('Y-m-d', $edt) . '"';
            $drDat = DbOperations::getObject()->fetchData($sql);
            if (count($drDat) < 1) {
                die('<h1>No doctor data to show</h1>');
            }
            $grTotInc = 0;
            $grTotDisc = 0;
            foreach ($drDat as $dr) {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center">Income by Dr. <?php echo $dr['dr_name']; ?> between Dt. <?php echo date('d-m-Y', $sdt); ?> to <?php echo date('d-m-Y', $edt); ?></div>

                        <?php
                        $drTot = 0;
                        $drTotDisc = 0;
                        $patSql = 'select'
                            . ' distinct(ptc_pat_id) as patid,'
                            . ' p_name'
                            . ' from patient_details, patient_test_calculations'
                            . ' where ptc_dr_id = "' . $dr['drid'] . '"'
                            . ' and ptc_pat_id = pid'
                            . ' and  date(ptc_dttm) between "' . date('Y-m-d', $sdt) . '" and "' . date('Y-m-d', $edt) . '"'
                            . ' order by p_name';
                        //die($patSql);
                        $patData = DbOperations::getObject()->fetchData($patSql);
                        $patCount = 0;
                        foreach ($patData as $pat) {
                            $fetchDiscSql = 'select sum(ptc_discount) as totdisc'
                                . ' from patient_test_calculations where ptc_pat_id = "' . $pat['patid'] . '"'
                                . ' and date(ptc_dttm) between "' . date('Y-m-d', $sdt) . '" and "' . date('Y-m-d', $edt) . '"'
                                . ' and ptc_dr_id = "' . $dr['drid'] . '"';
                            $priceDisc = DbOperations::getObject()->fetchData($fetchDiscSql);
                            $drTotDisc += floatval($priceDisc[0]['totdisc']);
                            $grTotDisc += floatval($priceDisc[0]['totdisc']);
                            ?>
                            <table class="table table-squeezed">
                                <caption><?php echo $pat['p_name']; ?></caption>
                                <thead>
                                    <tr>
                                        <th class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                            Date
                                        </th>
                                        <th class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            Tests Done
                                        </th>
                                        <th class="col-lg-2 col-md-2 col-sm-4 col-xs-2">
                                            Price
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totPrice = 0;
                                    $ptestsql = 'select'
                                        . ' ptc_dttm,'
                                        . ' test_name,'
                                        . ' pt_price'
                                        . ' from'
                                        . ' test_list, patient_tests, patient_test_calculations'
                                        . ' where '
                                        . ' pat_id = "' . $pat['patid'] . '"'
                                        . ' and pt_test_id = test_id'
                                        . ' and ptc_dr_id = "' . $dr['drid'] . '"'
                                        . ' and pt_dttm = ptc_dttm'
                                        . ' and date(pt_dttm) between "' . date('Y-m-d', $sdt) . '" and "' . date('Y-m-d', $edt) . '"'
                                        . ' order by pt_dttm';
                                    //die($ptestsql);
                                    $ptTestDat = DbOperations::getObject()->fetchData($ptestsql);
                                    foreach ($ptTestDat as $tstDat) {
                                        $totPrice += floatval($tstDat['pt_price']);
                                        $grTotInc += floatval($tstDat['pt_price']);
                                        $drTot += floatval($tstDat['pt_price']);
                                        ?>
                                        <tr>
                                            <td><?php echo date('d-m-Y', strtotime($tstDat['ptc_dttm'])); ?></td>
                                            <td><?php echo $tstDat['test_name']; ?></td>
                                            <td class="text-right"><?php echo number_format(floatval($tstDat['pt_price']), 2, '.', ','); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2">Total Income from the patient</td>
                                        <td class="text-right">
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <?php echo number_format(floatval($totPrice), 2, '.', ','); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">Total Discount to the patient</td>
                                        <td class="text-right">
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <?php echo number_format(floatval($priceDisc[0]['totdisc']), 2, '.', ','); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Grand total income from the patient</th>
                                        <th class="text-right">
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <?php echo number_format((floatval($totPrice) - floatval($priceDisc[0]['totdisc'])), 2, '.', ','); ?>
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php } ?>
                        <table class="table table-squeezed">
                            <tbody>
                                <tr>
                                    <td class="col-lg-10 col-md-10 col-sm-10 col-xs-10">Grand total income via the doctor</td>
                                    <td class="text-right col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($drTot), 2, '.', ','); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Grand total discount granted</td>
                                    <td class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($drTotDisc), 2, '.', ','); ?>
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-light">
                                    <td>Grand Income</td>
                                    <td class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format((floatval($drTot) - floatval($drTotDisc)), 2, '.', ','); ?>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            <?php } if (intval($grTotInc) > 0) { ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <table class="table table-striped table-bordered table-squeezed center">
                        <tbody>
                            <tr>
                                <td>Grand total income by all</td>
                                <td class="text-right"><?php echo number_format(floatval($grTotInc), 2, '.', ','); ?></td>
                            </tr>
                            <tr>
                                <td>Grand total discount</td>
                                <td class="text-right"><?php echo number_format(floatval($grTotDisc), 2, '.', ','); ?></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="border-light">
                                <td>Grand Income</td>
                                <td class="text-right"><?php echo number_format((floatval($grTotInc) - floatval($grTotDisc)), 2, '.', ','); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <?php
            }
            $sqlDoc = 'select dr_name, dr_org, dr_phone, staff_name, dr_created from doctor_details, staff_users where date(dr_created) between "' . date('Y-m-d', $sdt) . '" and "' . date('Y-m-d', $edt) . '" and dr_created_by = staff_id order by dr_created';
            $docDat = DbOperations::getObject()->fetchData($sqlDoc);
            if (count($docDat) > 0) {
                $cnt = 0;
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center">New Doctor Added between Dt. <?php echo date('d-m-Y', $sdt); ?> to <?php echo date('d-m-Y', $edt); ?></div>
                        <table class="table table-squeezed">
                            <thead>
                                <tr>
                                    <th>Sl.</th>
                                    <th>Name</th>
                                    <th>Org./Deptt./Area</th>
                                    <th>Contact</th>
                                    <th>Entered By</th>
                                    <th>Create Date Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($docDat as $doc) { ?>
                                    <tr>
                                        <td><?php print( ++$cnt); ?></td>
                                        <td><?php echo $doc['dr_name'] ?></td>
                                        <td><?php echo $doc['dr_org'] ?></td>
                                        <td><?php echo $doc['dr_phone'] ?></td>
                                        <td><?php echo $doc['staff_name'] ?></td>
                                        <td><?php echo date('d/m/Y h:i:s A', strtotime($doc['dr_created'])); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php
            }
            // get contents from buffer
            $contents = ob_get_contents();
            // clean and end the buffer
            ob_end_clean();

            $replacementArray = array(
                'PageTitle' => 'Income Details of doctor in a specific date range - JK Imaging',
                'CenterContents' => $contents,
                'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
                'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
            );

            assignTemplate($replacementArray, 'doctorIncomeTemplate.php');
            exit(0);
            break;

        default:
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">View all income today</div>
                    <div class="panel-body">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                            <thead>
                                <tr>
                                    <th>Test Category</th>
                                    <th>Number of Tests</th>
                                    <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                                $catData = DbOperations::getObject()->fetchData($sql);
                                $grTotTst = 0;
                                $grTotPrice = 0;
                                $tsql = 'select'
                                    . ' count(pt_id) as no_of_tests,'
                                    . ' sum(pt_price) as tot_rs'
                                    . ' from patient_tests, test_list'
                                    . ' where pt_test_id = test_id'
                                    . ' and pt_status = ?'
                                    . ' and under_cat = ?'
                                    . ' and date(pt_dttm) = ?';
                                    //. ' and pt_created_by = ?';
                                $tres = DbOperations::getObject()->prepareQuery($tsql);
                                $psql = 'select'
                                    . ' sum(ptc_tot_price) as sum_total_price,'
                                    . ' sum(ptc_discount) as sum_total_discount'
                                    . ' from patient_test_calculations'
                                    . ' where date(ptc_dttm) = ?'
                                    . ' and ptc_status = ?';
                                    //. ' and ptc_staff_id = "' . $_SESSION['UID'] . '"';
                                $pres = DbOperations::getObject()->prepareQuery($psql);
                                foreach ($catData as $cats) {
                                    $incDat = DbOperations::getObject()->fetchData('', [1, $cats['cat_id'], $dtRep], false, $tres);
                                    $grTotTst += intval($incDat[0]['no_of_tests']);
                                    $grTotPrice += floatval($incDat[0]['tot_rs']);
                                    ?>
                                    <tr>
                                        <td><?php echo $cats['cat_name']; ?></td>
                                        <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                        <td class="text-right">
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                $totDat = DbOperations::getObject()->fetchData('', [$dtRep, 1], false, $pres);
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="text-right">Sum Totals :</th>
                                    <th class="text-right"><?php print($grTotTst); ?></th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Discount :</th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Grand Total Income :</th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <?php if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                                    <tr>
                                        <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                                    </tr>
                                <?php } ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'View all income - JK Imaging User Dashboard';
            break;
    }
} else {
    $submittedData = DataFilter::getObject()->cleanData($_POST);
    if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
        $dtRep = DBDATE;
    } else {
        $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
    }
    ob_start();
    ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">View all income by you today</div>
            <div class="panel-body">
                <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                    <thead>
                        <tr>
                            <th>Test Category</th>
                            <th>Number of Tests</th>
                            <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                        $catData = DbOperations::getObject()->fetchData($sql);
                        $tsql = 'select count(pt_id) as no_of_tests, sum(pt_price) as tot_rs'
                                . ' from patient_tests, test_list where pt_test_id = test_id'
                                . ' and under_cat = ? and pt_status = ? and date(pt_dttm) = ?'
                                . ' and pt_created_by = ?';
                        $tres = DbOperations::getObject()->prepareQuery($tsql);
                        $psql = 'select sum(ptc_tot_price) as sum_total_price, sum(ptc_discount) as sum_total_discount, '
                            . ' sum(ptc_credit) as sum_credit from patient_test_calculations where date(ptc_dttm) = ?'
                            . ' and ptc_status = ? and ptc_staff_id = ?';
                        $totRes = DbOperations::getObject()->prepareQuery($psql);
                        $grTotTst = 0;
                        $grTotPrice = 0;
                        foreach ($catData as $cats) {
                            $incDat = DbOperations::getObject()->fetchData('', [$cats['cat_id'], 1, $dtRep, $_SESSION['UID']]);
                            $grTotTst += intval($incDat[0]['no_of_tests']);
                            $grTotPrice += floatval($incDat[0]['tot_rs']);
                            ?>
                            <tr>
                                <td><?php echo $cats['cat_name']; ?></td>
                                <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                <td class="text-right"><span class="fa fa-rupee"></span>&nbsp;<?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                            </tr>
                            <?php
                        }
                        $totDat = DbOperations::getObject()->fetchData('', [$dtRep, 1, $_SESSION['UID']], false, $totRes);
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th class="text-right">Sum Totals :</th>
                            <th class="text-right"><?php print($grTotTst); ?></th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="text-right" colspan="2">Total Discount :</th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="text-right" colspan="2">Total Credit :</th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="text-right" colspan="2">Grand Total Income :</th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <?php if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                            <tr>
                                <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                            </tr>
                        <?php } ?>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php
    $pageTitle = 'View all income by you - JK Imaging User Dashboard';
}
// get contents from buffer
$contents = ob_get_contents();
// clean and end the buffer
ob_end_clean();

$replacementArray = array(
    'PageTitle' => $pageTitle,
    'ErrorMessages' => getAlertMsg(),
    'CenterContents' => $contents,
    'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'bootstrap-datetimepicker.min.css', 'dataTables.bootstrap.min.css', 'custom.min.css'),
    'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'bootstrap-typeahead.min.js', 'moment.min.js', 'bootstrap-datetimepicker.min.js', 'jquery.dataTables.min.js', 'dataTables.bootstrap.min.js', 'custom.min.js')
);

assignTemplate($replacementArray);
// the ending php tag has been intentionally not used to avoid unwanted whitespaces before document starts
