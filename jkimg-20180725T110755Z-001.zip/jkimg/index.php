<?php
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
if (isLogged() !== false){redirectUser();}
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Login Panel for JK Imaging">
        <meta name="author" content="Kirti Kumar Nayak <admin@thebestfreelancer.in>">
        <link rel="shortcut icon" href="helpers/css/images/jk.ico">
        <title>Log in To JK Imaging</title>
        <!-- Bootstrap core CSS -->
        <link href="helpers/css/bootstrap.min.css" rel="stylesheet">
        <link href="helpers/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="helpers/css/font-awesome.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="helpers/css/custom.min.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="helpers/js/html5.js"></script>
          <script src="helpers/js/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div class="container">
            <form class="form-signin" role="form" name="signin" id="signin" action="login.php" method="post">
                <div class="black-shadow">
                    <h2 class="text-center text-danger">JK Imaging</h2>
                    <?php echo getAlertMsg(); ?>
                    <label for="uname" class="sr-only">Username</label>
                    <div class="input-group margin-bottom-sm firstOne">
                        <span class="input-group-addon"><i class="fa fa-user-secret fa-fw"></i></span>
                        <input type="text" id="uname" name="uname" class="form-control" title="Enter your  username" data-toggle="tooltip" data-placement="top" placeholder="Username" required autofocus>
                    </div>
                    <label for="pass" class="sr-only">Password</label>
                    <div class="input-group lastOne">
                        <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                        <input type="password" id="pass" name="pass" class="form-control" title="Enter your password" data-toggle="tooltip" data-placement="top" placeholder="Password" required>
                    </div>
                    <button class="btn btn-lg btn-danger btn-block" id="signin" data-loading-text="<i class='fa fa-spinner fa-pulse'></i> Authenticating...!" name="signin" type="submit"><i class="fa fa-sign-in"></i> Sign in</button>
                </div>
            </form>
        </div>
        <script src="helpers/js/jquery.min.js"></script>
        <script src="helpers/js/bootstrap.min.js"></script>
        <script src="helpers/js/custom.min.js"></script>
    </body>
</html>
