<?php
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
$sql = 'select subcat_id, subcat_name from test_subcats where subcat_id = 18';
$testData = DbOperations::getObject()->fetchData($sql);
$sql = 'select test_id, test_name, test_price from test_list where under_subcat = ? order by test_name';
$res = DbOperations::getObject()->conn->prepare($sql);

/*echo '<pre>';
print_r($testData);
echo '</pre>';exit;*/
ob_start();
?>
<?php
foreach ($testData as $testScats):
	$res->execute(array($testScats['subcat_id']));
	$rows = $res->fetchAll();
?>
<h4 class="text-center">Rate Chart</h4>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top:5px;">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title text-center"><?php echo strtoupper($testScats['subcat_name']); ?></h3>
		</div>
		<table class="table table-squeezed table-bordered">
			<thead>
				<tr>
					<th class="col-lg-9 col-md-9 col-sm-9 col-xs-9">Test Name</th>
					<th class="col-lg-3 col-md-3 col-sm-3 col-xs-3 text-right">Test Price (<img src="<?php echo ACCESS_URL; ?>helpers/css/images/rupee.gif" alt="Rs." style="display: inline;border: 0;">)</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($rows as $tests): ?>
				<tr>
					<td><?php echo $tests['test_name']; ?></td>
					<td class="text-right"><?php echo number_format(floatVal($tests['test_price']), 2, '.', ','); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endforeach; ?>
<?php
// get contents from buffer
$contents                           = ob_get_contents();
// clean and end the buffer
ob_end_clean();

$replacementArray                   = array(
	'PageTitle'                     => 'Print Test List - JK Diagnostics',
	'CenterContents'                => $contents,
	'CSSHelpers'                    => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
	'JSHelpers'                     => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
);

assignTemplate($replacementArray, 'test-rate-template.php');
exit(0);