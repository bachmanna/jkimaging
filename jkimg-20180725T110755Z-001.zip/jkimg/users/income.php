<?php
// common include file required
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
// throw out the user if it is not admin
if (isLogged() !== '2') {
    header("Location:" . ACCESS_URL);
    exit(0);
}
// extract get data to get option by user
$opt = DataFilter::getObject()->cleanData($_GET);

if (isset($opt['opt']) and ! empty($opt['opt'])) {
    switch ($opt['opt']) {

        case 'oneDay':
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-info">
                    <div class="panel-heading">View all income one day</div>
                    <div class="panel-body">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                            <thead>
                                <tr><th colspan="3" class="text-center success"><h4>Morning Session</h4></th></tr>
                                <tr>
                                    <th>Test Category</th>
                                    <th>Number of Tests</th>
                                    <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                                $catData = DbOperations::getObject()->fetchData($sql);
                                $grTotTst = 0;
                                $grTotPrice = 0;
                                $finalTotTst = 0;
                                $finalTotPrice = 0;
                                $finalTotDisc = 0;
                                foreach ($catData as $cats) {

                                    $tsql = 'select'
                                        . ' count(pt_id) as no_of_tests,'
                                        . ' sum(pt_price) as tot_rs'
                                        . ' from patient_tests left join test_list'
                                        . ' on pt_test_id = test_id'
                                        . ' where'
                                        . ' under_cat = "' . $cats['cat_id'] . '"'
                                        . ' and date(pt_dttm) = "' . $dtRep . '"'
                                        . ' and time(pt_dttm) < "15:00:00"'
                                        . ' and pt_status ="1"';//die($tsql);

                                    $incDat = DbOperations::getObject()->fetchData($tsql);
                                    $grTotTst += intval($incDat[0]['no_of_tests']);
                                    $grTotPrice += floatval($incDat[0]['tot_rs']);
                                    ?>
                                    <tr>
                                        <td><?php echo $cats['cat_name']; ?></td>
                                        <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                        <td class="text-right"><span class="fa fa-rupee"></span>&nbsp;<?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                                    </tr>
                                    <?php
                                }
                                $psql = 'select'
                                    . ' sum(ptc_tot_price) as sum_total_price,'
                                    . ' sum(ptc_discount) as sum_total_discount'
                                    . ' from patient_test_calculations'
                                    . ' where'
                                    . ' date(ptc_dttm) = "' . $dtRep . '"'
                                    . ' and time(ptc_dttm) < "15:00:00"'
                                    . ' and ptc_status = "1"';
                                $totDat = DbOperations::getObject()->fetchData($psql);
                                ?>
                                <tr>
                                    <th class="text-right">Sum Totals :</th>
                                    <th class="text-right"><?php print($grTotTst); ?></th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Discount :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Income :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr><th colspan="3" class="text-center danger"><h4>Evening Session</h4></th><?php
                                $finalTotTst += $grTotTst;
                                $finalTotPrice += $grTotPrice;
                                $finalTotDisc += floatval($totDat[0]['sum_total_discount']);
								//var_dump($finalTotDisc);
								$incDat = array();
                                $grTotTst = 0; $grTotPrice = 0;
                                foreach ($catData as $cats) {

                                    $tsql = 'select'
                                        . ' count(pt_id) as no_of_tests,'
                                        . ' sum(pt_price) as tot_rs'
                                        . ' from patient_tests left join test_list'
                                        . ' on pt_test_id = test_id'
                                        . ' where'
                                        . ' under_cat = "' . $cats['cat_id'] . '"'
                                        . ' and date(pt_dttm) = "' . $dtRep . '"'
                                        . ' and time(pt_dttm) >= "15:00:00"'
                                        . ' and pt_status ="1"';

                                    $incDat = DbOperations::getObject()->fetchData($tsql);
                                    $grTotTst += intval($incDat[0]['no_of_tests']);
                                    $grTotPrice += floatval($incDat[0]['tot_rs']);
                                    ?>
                                    <tr>
                                        <td><?php echo $cats['cat_name']; ?></td>
                                        <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                        <td class="text-right"><span class="fa fa-rupee"></span>&nbsp;<?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                            <tfoot>
                                <?php
                                $finalTotTst += $grTotTst;
                                $finalTotPrice += $grTotPrice;
                                //$finalTotDisc += floatval($totDat[0]['sum_total_discount']);
                                $psql = 'select'
                                    . ' sum(ptc_tot_price) as sum_total_price,'
                                    . ' sum(ptc_discount) as sum_total_discount'
                                    . ' from patient_test_calculations'
                                    . ' where'
                                    . ' date(ptc_dttm) = "' . $dtRep . '"'
                                    . ' and time(ptc_dttm) >= "15:00:00"'
                                    . ' and ptc_status = "1"';
                                $totDat = DbOperations::getObject()->fetchData($psql);
								$finalTotDisc += floatval($totDat[0]['sum_total_discount']);
                                ?>
                                <tr>
                                    <th class="text-right">Sum Totals :</th>
                                    <th class="text-right"><?php print($grTotTst); ?></th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Discount :</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right">Grand Totals :</th>
                                    <th class="text-right"><?php print($finalTotTst); ?> Tests</th>
                                    <th class="text-right">
                                        <span class="fa fa-rupee"></span>&nbsp;
                                        <?php echo number_format((floatval($finalTotPrice) - floatval($finalTotDisc)), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <?php /*if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                                    <tr>
                                        <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                                    </tr>
                                <?php }*/ ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'View all income in one day - JK Diagnostics User Dashboard';
            break;

        case 'sdate':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-info">
                    <div class="panel-heading">Select a date to view income details</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="anotherpatform" name="anotherpatform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=oneDay">
                            <div class="form-group">
                                <label for="dt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="dt" name="dt" required="required" autocomplete="off" placeholder="Date to show">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date to view the income - JK Diagnostics User Dashboard';
            break;


        case 'doctorToday':

            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            $sql = 'select distinct(ptc_dr_id) as drid, dr_name, dr_org '
                . 'from patient_test_calculations left join doctor_details '
                . 'on dr_id = ptc_dr_id '
                . 'where ptc_status = "1" '
                . 'and date(ptc_dttm) = "' . $dtRep . '" '
                . 'and time(ptc_dttm) < "15:00:00"';
                        //die($sql);
            $drDat = DbOperations::getObject()->fetchData($sql);
            $grTotInc = 0;
            $grTotDisc = 0;
            $finalTotInc = 0;
            $finalTotDisc = 0;
            ?>
            <h3 class="text-center bg-primary">Morning Session</h3>
            <?php
            if (count($drDat) < 1) {
                echo('<h4 class="text-center">No doctor data to show</h4>');
            } else {
            foreach ($drDat as $dr) {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-info" style="margin-bottom: 5px">
                        <div class="panel-heading text-center" style="padding: 2px;font-weight: 700">
                            Dr. <?php echo $dr['dr_name']; ?>
                            <?php echo ($dr['dr_org'] !== '' ? ' (' . $dr['dr_org'] . ')' : ''); ?>
                        </div>

                        <?php
                        $drTot = 0;
                        $drTotDisc = 0;
                        $patSql = 'select'
                            . ' distinct(ptc_pat_id) as patid,'
                            . ' p_name'
                            . ' from patient_details left join patient_test_calculations'
                            . ' on ptc_pat_id = pid'
                            . ' where ptc_dr_id = "' . $dr['drid'] . '"'
                            . ' and ptc_status = "1"'
                            . ' and date(ptc_dttm) = "' . $dtRep . '"'
							. ' and time(ptc_dttm) < "15:00:00"';
                        //die($patSql);
                        $patData = DbOperations::getObject()->fetchData($patSql);
                        $patCount = 0;
                        foreach ($patData as $pat) {
                            $fetchDiscSql = 'select sum(ptc_discount) as totdisc'
                                . ' from patient_test_calculations where ptc_pat_id = "' . $pat['patid'] . '"'
                                . ' and date(ptc_dttm) = "' . $dtRep . '"'
								. ' and time(ptc_dttm) < "15:00:00"'
                                . ' and ptc_dr_id = "' . $dr['drid'] . '"'
                                . ' and ptc_status = "1"';
                            $priceDisc = DbOperations::getObject()->fetchData($fetchDiscSql);
                            $drTotDisc += floatval($priceDisc[0]['totdisc']);
                            $grTotDisc += floatval($priceDisc[0]['totdisc']);
                            ?>
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-squeezed">
                                <caption><?php echo $pat['p_name']; ?></caption>
                                <thead>
                                    <tr>
                                        <th class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            Tests Done
                                        </th>
                                        <th class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
                                            By
                                        </th>
                                        <th class="col-lg-3 col-md-3 col-sm-3 col-xs-3 text-right">
                                            Price
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totPrice = 0;
                                    $ptestsql = 'select'
                                        . ' test_name,'
                                        . ' pt_price, pt_status, staff_name'
                                        . ' from'
                                        . ' test_list left join patient_tests on pt_test_id = test_id'
										. ' left join patient_test_calculations on pt_dttm = ptc_dttm'
										. ' left join staff_users on ptc_staff_id = staff_id'
                                        . ' where '
                                        . ' pat_id = "' . $pat['patid'] . '"'
                                        //. ' and pt_created_by = staff_id'
                                        . ' and ptc_status = "1"'
                                        . ' and ptc_dr_id = "' . $dr['drid'] . '"'
                                        . ' and date(pt_dttm) = "' . $dtRep . '"'
										. ' and time(pt_dttm) < "15:00:00"';
                                    //die($ptestsql);
                                    $ptTestDat = DbOperations::getObject()->fetchData($ptestsql);
                                    foreach ($ptTestDat as $tstDat) {
                                        $totPrice += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        $grTotInc += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        $drTot += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        ?>
                                        <tr>
                                            <td><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">' . $tstDat['test_name'] . '</i>' : $tstDat['test_name']); ?></td>
                                            <td>
                                                <?php
                                                $pieces = explode(' ', $tstDat['staff_name']);
                                                if (count($pieces) > 1) {
                                                    echo substr($pieces[0], 0, 1) . '.' . substr($pieces[1], 0, 1);
                                                } else {
                                                    echo substr($pieces[0], 0, 3);
                                                }
                                                ?>
                                            </td>
                                            <td class="text-right"><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">N/A</i>' : number_format(floatval($tstDat['pt_price']), 2, '.', ',')); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Grand total price (Total &hyphen; Discount) from patient</th>
                                        <td class="text-right" colspan="2">
                                            (<?php echo number_format(floatval($totPrice), 2, '.', ','); ?>
                                            &hyphen;
                                            <?php echo number_format(floatval($priceDisc[0]['totdisc']), 2, '.', ','); ?>
                                            &equals;)&nbsp;
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <strong><?php echo number_format((floatval($totPrice) - floatval($priceDisc[0]['totdisc'])), 2, '.', ','); ?></strong>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php } ?>

                    </div>
                </div>
            <?php } if (intval($grTotInc) > 0) { ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center" style="padding:2px">Total Income on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?> (Morning Session)</div>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-squeezed center">
                            <tbody>
                                <tr>
                                    <td>Grand Total income (Morning)</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotInc), 2, '.', ','); $finalTotInc+=$grTotInc; ?></td>
                                </tr>
                                <tr>
                                    <td>Grand Total discount (Morning)</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotDisc), 2, '.', ','); $finalTotDisc+=$grTotDisc; ?></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-light">
                                    <td>Grand Income (Morning)</td>
                                    <td class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format((floatval($grTotInc) - floatval($grTotDisc)), 2, '.', ','); ?>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <?php
            }}
            $sql = 'select distinct(ptc_dr_id) as drid, dr_name, dr_org '
                . 'from patient_test_calculations left join doctor_details '
                . 'on dr_id = ptc_dr_id '
                . 'where ptc_status = "1" '
                . 'and date(ptc_dttm) = "' . $dtRep . '" '
                . 'and time(ptc_dttm) >= "15:00:00"';
                        //die($sql);
            $drDat = DbOperations::getObject()->fetchData($sql);
            $grTotInc = 0;
            $grTotDisc = 0;
            ?>
            <div class="clearfix"></div>
            <h3 class="text-center bg-danger" style="page-break-before: always">Evening Session</h3>
            <div class="clearfix"></div>
            <?php
            if (count($drDat) < 1) {
                echo('<h4 class="text-center">No doctor data to show</h4>');
            } else {
            foreach ($drDat as $dr) {
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-info" style="margin-bottom: 5px">
                        <div class="panel-heading text-center" style="padding: 2px;font-weight: 700">
                            Dr. <?php echo $dr['dr_name']; ?>
                            <?php echo ($dr['dr_org'] !== '' ? ' (' . $dr['dr_org'] . ')' : ''); ?>
                        </div>

                        <?php
                        $drTot = 0;
                        $drTotDisc = 0;
                        $patSql = 'select'
                            . ' distinct(ptc_pat_id) as patid,'
                            . ' p_name'
                            . ' from patient_details left join patient_test_calculations'
                            . ' on ptc_pat_id = pid'
                            . ' where ptc_dr_id = "' . $dr['drid'] . '"'
                            . ' and ptc_status = "1"'
                            . ' and date(ptc_dttm) = "' . $dtRep . '"'
							. ' and time(ptc_dttm) >= "15:00:00"';
                        //die($patSql);
                        $patData = DbOperations::getObject()->fetchData($patSql);
                        $patCount = 0;
                        foreach ($patData as $pat) {
                            $fetchDiscSql = 'select sum(ptc_discount) as totdisc'
                                . ' from patient_test_calculations where ptc_pat_id = "' . $pat['patid'] . '"'
                                . ' and date(ptc_dttm) = "' . $dtRep . '"'
								. ' and time(ptc_dttm) >= "15:00:00"'
                                . ' and ptc_dr_id = "' . $dr['drid'] . '"'
                                . ' and ptc_status = "1"';
                            $priceDisc = DbOperations::getObject()->fetchData($fetchDiscSql);
                            $drTotDisc += floatval($priceDisc[0]['totdisc']);
                            $grTotDisc += floatval($priceDisc[0]['totdisc']);
                            ?>
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-squeezed">
                                <caption><?php echo $pat['p_name']; ?></caption>
                                <thead>
                                    <tr>
                                        <th class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            Tests Done
                                        </th>
                                        <th class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
                                            By
                                        </th>
                                        <th class="col-lg-3 col-md-3 col-sm-3 col-xs-3 text-right">
                                            Price
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $totPrice = 0;
                                    $ptestsql = 'select'
                                        . ' test_name,'
                                        . ' pt_price, pt_status, staff_name'
                                        . ' from'
                                        . ' test_list left join patient_tests on pt_test_id = test_id'
										. ' left join patient_test_calculations on pt_dttm = ptc_dttm'
										. ' left join staff_users on ptc_staff_id = staff_id'
                                        . ' where '
                                        . ' pat_id = "' . $pat['patid'] . '"'
                                        //. ' and pt_created_by = staff_id'
                                        . ' and ptc_status = "1"'
                                        . ' and ptc_dr_id = "' . $dr['drid'] . '"'
                                        . ' and date(pt_dttm) = "' . $dtRep . '"'
										. ' and time(pt_dttm) >= "15:00:00"';
                                    //die($ptestsql);
                                    $ptTestDat = DbOperations::getObject()->fetchData($ptestsql);
                                    foreach ($ptTestDat as $tstDat) {
                                        $totPrice += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        $grTotInc += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        $drTot += ($tstDat['pt_status'] === '0' ? 0 : floatval($tstDat['pt_price']));
                                        ?>
                                        <tr>
                                            <td><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">' . $tstDat['test_name'] . '</i>' : $tstDat['test_name']); ?></td>
                                            <td>
                                                <?php
                                                $pieces = explode(' ', $tstDat['staff_name']);
                                                if (count($pieces) > 1) {
                                                    echo substr($pieces[0], 0, 1) . '.' . substr($pieces[1], 0, 1);
                                                } else {
                                                    echo substr($pieces[0], 0, 3);
                                                }
                                                ?>
                                            </td>
                                            <td class="text-right"><?php echo ($tstDat['pt_status'] === '0' ? '<i class="text-danger">N/A</i>' : number_format(floatval($tstDat['pt_price']), 2, '.', ',')); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Grand total price (Total &hyphen; Discount) from patient</th>
                                        <td class="text-right" colspan="2">
                                            (<?php echo number_format(floatval($totPrice), 2, '.', ','); ?>
                                            &hyphen;
                                            <?php echo number_format(floatval($priceDisc[0]['totdisc']), 2, '.', ','); ?>
                                            &equals;)&nbsp;
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <strong><?php echo number_format((floatval($totPrice) - floatval($priceDisc[0]['totdisc'])), 2, '.', ','); ?></strong>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php } ?>

                    </div>
                </div>
            <?php } if (intval($grTotInc) > 0) { ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center" style="padding:2px">Total Income on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?> (Evening Session)</div>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-squeezed center">
                            <tbody>
                                <tr>
                                    <td>Grand Total income (Evening)</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotInc), 2, '.', ',');$finalTotInc+=$grTotInc; ?></td>
                                </tr>
                                <tr>
                                    <td>Grand Total discount (Evening)</td>
                                    <td class="text-right"><?php echo number_format(floatval($grTotDisc), 2, '.', ',');$finalTotDisc+=$grTotDisc; ?></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="border-light">
                                    <td>Grand Income (Evening)</td>
                                    <td class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format((floatval($grTotInc) - floatval($grTotDisc)), 2, '.', ','); ?>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <?php }} ?>
            <div class="clearfix" style="page-break-after: always"></div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="page-break-before: always">
                <?php if (intval($finalTotInc) > 0) { ?>
                <div class="panel panel-default">
                    <div class="panel-heading text-center" style="padding:2px">Final Total Income on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?></div>
                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-squeezed center">
                        <tbody>
                            <tr>
                                <td>Grand Total income by all</td>
                                <td class="text-right"><?php echo number_format(floatval($finalTotInc), 2, '.', ','); ?></td>
                            </tr>
                            <tr>
                                <td>Grand Total discount</td>
                                <td class="text-right"><?php echo number_format(floatval($finalTotDisc), 2, '.', ',');?></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="border-light">
                                <td>Grand Income</td>
                                <td class="text-right">
                                    <i class="fa fa-rupee"></i>&nbsp;
                                    <?php echo number_format((floatval($finalTotInc) - floatval($finalTotDisc)), 2, '.', ','); ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php }
            $sqlDoc = 'select dr_name, dr_org, dr_phone,'
                . ' staff_name, dr_created '
                . 'from doctor_details, staff_users'
                . ' where date(dr_created) = "' . $dtRep . '"'
                . ' and dr_created_by = staff_id';
            $docDat = DbOperations::getObject()->fetchData($sqlDoc);
            if (count($docDat) > 0) {
                $cnt = 0;
                ?>
                <div class="panel panel-default">
                    <div class="panel-heading text-center" style="padding:2px">New Doctor Added on Dt. <?php echo date('d-m-Y', strtotime($dtRep)); ?></div>
                    <table cellpadding="0" cellspacing="0" border="0" class="table table-squeezed">
                        <thead>
                            <tr>
                                <th>Sl.</th>
                                <th>Name</th>
                                <th>Org./Deptt./Area</th>
                                <th>Contact</th>
                                <th>Entered By</th>
                                <th>Create Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($docDat as $doc) { ?>
                                <tr>
                                    <td><?php print( ++$cnt); ?></td>
                                    <td><?php echo $doc['dr_name'] ?></td>
                                    <td><?php echo $doc['dr_org'] ?></td>
                                    <td><?php echo $doc['dr_phone'] ?></td>
                                    <td><?php echo $doc['staff_name'] ?></td>
                                    <td><?php echo date('h:i:s A', strtotime($doc['dr_created'])); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>
            </div>
            <?php
            // get contents from buffer
            $contents = ob_get_contents();
            // clean and end the buffer
            ob_end_clean();

            $replacementArray = array(
                'PageTitle' => 'Income Details of doctor in a specific day - JK Diagnostics',
                'CenterContents' => $contents,
                'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
                'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
            );

            assignTemplate($replacementArray, 'doctorIncomeTemplate.php');
            exit(0);
            break;

        case 'doctorSdate':
            ob_start();
            ?>
            <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Select a date to view income details via doctors</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" id="docIncform" name="docIncform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=doctorToday">
                            <div class="form-group">
                                <label for="dt" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Date: </label>
                                <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <input type="text" class="form-control datepicker" data-date-format="DD-MM-YYYY" id="dt" name="dt" required="required" autocomplete="off" placeholder="Date to show">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                    <button type="submit" name="showDet" id="showDet" class="btn btn-default">Show Details</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Select a date to view the income via doctor - JK Diagnostics User Dashboard';
            break;

        default:
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
                $dtRep = DBDATE;
            } else {
                $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
            }
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">View all income by you today</div>
                    <div class="panel-body">
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                            <thead>
                                <tr>
                                    <th>Test Category</th>
                                    <th>Number of Tests</th>
                                    <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                                $catData = DbOperations::getObject()->fetchData($sql);
                                $grTotTst = 0;
                                $grTotPrice = 0;
                                foreach ($catData as $cats) {

                                    $tsql = 'select'
                                        . ' count(pt_id) as no_of_tests,'
                                        . ' sum(pt_price) as tot_rs'
                                        . ' from patient_tests, test_list'
                                        . ' where'
                                        . ' pt_test_id = test_id'
                                        . ' and pt_status = "1"'
                                        . ' and under_cat = "' . $cats['cat_id'] . '"'
                                        . ' and date(pt_dttm) = "' . $dtRep . '"'
                                        . ' and pt_created_by = "' . $_SESSION['UID'] . '"';

                                    $incDat = DbOperations::getObject()->fetchData($tsql);
                                    $grTotTst += intval($incDat[0]['no_of_tests']);
                                    $grTotPrice += floatval($incDat[0]['tot_rs']);
                                    ?>
                                    <tr>
                                        <td><?php echo $cats['cat_name']; ?></td>
                                        <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                        <td class="text-right">
                                            <i class="fa fa-rupee"></i>&nbsp;
                                            <?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                $psql = 'select'
                                    . ' sum(ptc_tot_price) as sum_total_price,'
                                    . ' sum(ptc_discount) as sum_total_discount'
                                    . ' from patient_test_calculations'
                                    . ' where'
                                    . ' date(ptc_dttm) = "' . $dtRep . '"'
                                    . ' and ptc_status = "1"'
                                    . ' and ptc_staff_id = "' . $_SESSION['UID'] . '"';
                                $totDat = DbOperations::getObject()->fetchData($psql);
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th class="text-right">Sum Totals :</th>
                                    <th class="text-right"><?php print($grTotTst); ?></th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Total Discount :</th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <tr>
                                    <th class="text-right" colspan="2">Grand Total Income :</th>
                                    <th class="text-right">
                                        <i class="fa fa-rupee"></i>&nbsp;
                                        <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                                    </th>
                                </tr>
                                <?php if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                                    <tr>
                                        <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                                    </tr>
                                <?php } ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'View all income by you - JK Diagnostics User Dashboard';
            break;
    }
} else {
    $submittedData = DataFilter::getObject()->cleanData($_POST);
    if (!isset($submittedData['dt']) or ( $submittedData['dt'] === '')) {
        $dtRep = DBDATE;
    } else {
        $dtRep = date('Y-m-d', strtotime($submittedData['dt']));
    }
    ob_start();
    ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">View all income by you today</div>
            <div class="panel-body">
                <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered table-hover center">
                    <thead>
                        <tr>
                            <th>Test Category</th>
                            <th>Number of Tests</th>
                            <th>Total Price (<span class="fa fa-rupee"></span>)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                        $catData = DbOperations::getObject()->fetchData($sql);
                        $grTotTst = 0;
                        $grTotPrice = 0;
                        foreach ($catData as $cats) {

                            $tsql = 'select'
                                . ' count(pt_id) as no_of_tests,'
                                . ' sum(pt_price) as tot_rs'
                                . ' from patient_tests, test_list'
                                . ' where'
                                . ' pt_test_id = test_id'
                                . ' and under_cat = "' . $cats['cat_id'] . '"'
                                . ' and pt_status = "1"'
                                . ' and date(pt_dttm) = "' . $dtRep . '"'
                                . ' and pt_created_by = "' . $_SESSION['UID'] . '"';

                            $incDat = DbOperations::getObject()->fetchData($tsql);
                            $grTotTst += intval($incDat[0]['no_of_tests']);
                            $grTotPrice += floatval($incDat[0]['tot_rs']);
                            ?>
                            <tr>
                                <td><?php echo $cats['cat_name']; ?></td>
                                <td class="text-right"><?php echo $incDat[0]['no_of_tests']; ?></td>
                                <td class="text-right"><span class="fa fa-rupee"></span>&nbsp;<?php echo number_format(floatval($incDat[0]['tot_rs']), 2, '.', ','); ?></td>
                            </tr>
                            <?php
                        }
                        $psql = 'select'
                            . ' sum(ptc_tot_price) as sum_total_price,'
                            . ' sum(ptc_discount) as sum_total_discount'
                            . ' from patient_test_calculations'
                            . ' where'
                            . ' date(ptc_dttm) = "' . $dtRep . '"'
                            . ' and ptc_status = "1"'
                            . ' and ptc_staff_id = "' . $_SESSION['UID'] . '"';
                        $totDat = DbOperations::getObject()->fetchData($psql);
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th class="text-right">Sum Totals :</th>
                            <th class="text-right"><?php print($grTotTst); ?></th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format(floatval($grTotPrice), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="text-right" colspan="2">Total Discount :</th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format(floatval($totDat[0]['sum_total_discount']), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <tr>
                            <th class="text-right" colspan="2">Grand Total Income :</th>
                            <th class="text-right">
                                <span class="fa fa-rupee"></span>&nbsp;
                                <?php echo number_format((floatval($grTotPrice) - floatval($totDat[0]['sum_total_discount'])), 2, '.', ','); ?>
                            </th>
                        </tr>
                        <?php if (floatval($grTotPrice) !== floatval($totDat[0]['sum_total_price'])) { ?>
                            <tr>
                                <th class="text-center text-danger" colspan="3">The income data mismatches, there seems an error in entry.</th>
                            </tr>
                        <?php } ?>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php
    $pageTitle = 'View all income by you - JK Diagnostics User Dashboard';
}
// get contents from buffer
$contents = ob_get_contents();
// clean and end the buffer
ob_end_clean();

$replacementArray = array(
    'PageTitle' => $pageTitle,
    'ErrorMessages' => getAlertMsg(),
    'CenterContents' => $contents,
    'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'bootstrap-datetimepicker.min.css', 'dataTables.bootstrap.min.css', 'custom.min.css'),
    'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'bootstrap-typeahead.min.js', 'moment.min.js', 'bootstrap-datetimepicker.min.js', 'jquery.dataTables.min.js', 'dataTables.bootstrap.min.js', 'custom.min.js')
);

assignTemplate($replacementArray);
// the ending php tag has been intentionally not used to avoid unwanted whitespaces before document starts
