<?php
// common include file required
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
// throw out the user if it is not admin
if (isLogged() !== '2') {
    header("Location:" . ACCESS_URL);
    exit (0);
}
// extract get data to get option by user
$opt                                = DataFilter::getObject()->cleanData($_GET);

if (isset($opt['opt']) and ! empty($opt['opt'])) {
    switch ($opt['opt']) {
        // show add new doctor form
        case 'add':
            ob_start();
            ?>
            <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1">
                <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-heading">Add New Test Details</div>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" id="testform" name="testform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=saveNewTest">
                                <div class="form-group">
                                    <label for="cat" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Under Category : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <select class="form-control" id="cat" name="cat" onchange="loadSubCats(this);">
                                            <option value="">Select</option>
                                            <?php
                                            $sql = 'select cat_id, cat_name from test_cats where cat_id not in (3, 5) order by cat_name';
                                            $cats = DbOperations::getObject()->fetchData($sql);
                                            foreach ($cats as $value) {
                                            ?>
                                            <option value="<?php echo $value['cat_id'] ?>"><?php echo $value['cat_name'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="scat" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Under Sub-category : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <select name="scat" id="scat" class="form-control">
                                            <option value="">Select</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tname" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Test Name : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <input type="text" class="form-control" id="tname" name="tname" required="required" autocomplete="off" placeholder="Name of the test">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tprice" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Test Price : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <input type="text" class="form-control" id="tprice" name="tprice" required="required" autocomplete="off" placeholder="Price of the test in numbers or decimal">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <button type="submit" name="saveDoct" id="saveTest" class="btn btn-default">Save Test</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle = 'Add a new test - JK Diagnostics User Dashboard';
            break;

        case 'subcatsUnderCat':
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (isset($submittedData['catid']) and !empty($submittedData['catid'])) {
                $scats = DbOperations::getObject()->fetchData('select subcat_id, subcat_name from test_subcats where under_cat = "' . $submittedData['catid'] . '"');
                echo '<option value="">Select</option>';
                foreach ($scats as $value) {
                    echo '<option value="' . $value['subcat_id'] . '">' . $value['subcat_name'] . '</option>';
                }
            } else {
                echo '<option value="">Select</option>';
            }
            exit;
            break;
        // save the employee data posted from the new employee form
        case 'saveNewTest':
            // clean the data recieved
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            
            // validate the data
            if (!isset($submittedData['cat']) or empty($submittedData['cat'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must select a test category';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['scat']) or empty($submittedData['scat'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must select a test sub-category';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            
            if (!isset($submittedData['tname']) or empty($submittedData['tname'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must enter the test name';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['tprice']) or is_nan($submittedData['tprice'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must enter the test price in numbers';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            // make a data array to be saves as in database table
            $saveData = array(
                'test_name'           => ucwords($submittedData['tname']),
                'test_price'            => floatval($submittedData['tprice']),
                'under_cat'          => $submittedData['cat'],
                'under_subcat'          => $submittedData['scat'],
                'test_created_by'     => $_SESSION['UID'],
                'test_created'        => DBTIMESTAMP
            );
            // start a transaction with database
            DbOperations::getObject()->commitTransaction('start');
            // insert the data
            $success                = DbOperations::getObject()->insertData('test_list', $saveData);
            if ($success) {
                // if success commit the transaction and set a message in session
                DbOperations::getObject()->commitTransaction('on');
                $_SESSION['STATUS'] = 'success';
                $_SESSION['MSG']    = 'You have successfully added a new test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            } else {
                // else rollback the data inserted and set an error message in session
                DbOperations::getObject()->commitTransaction('rollback');
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'Error occured while adding a test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            break;
        
        // show the form to edit the selected employee
        case 'edit':
            if (!isset($opt['tid']) or empty($opt['tid'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'No test data found';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            $sql = 'select test_id, test_name, test_price, under_cat, under_subcat from test_list where test_id = "' . $opt['tid'] . '"';
            $tData = DbOperations::getObject()->fetchData($sql);
            ob_start();
            ?>
            <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-1">
                <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-heading">Edit Test Details</div>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" id="testform" name="testform" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?opt=saveEditedTest">
                                <div class="form-group">
                                    <label for="cat" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Under Category : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <select class="form-control" id="cat" name="cat" onchange="loadSubCats(this);">
                                            <option value="">Select</option>
                                            <?php
                                            $sql = 'select cat_id, cat_name from test_cats order by cat_name';
                                            $cats = DbOperations::getObject()->fetchData($sql);
                                            foreach ($cats as $value) {
                                            ?>
                                            <option<?php echo ($tData[0]['under_cat'] === $value['cat_id'] ? ' selected="selected"' : ''); ?> value="<?php echo $value['cat_id'] ?>"><?php echo $value['cat_name'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="scat" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Under Sub-category : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <select name="scat" id="scat" class="form-control">
                                            <option value="">Select</option>
                                            <?php
                                            $scats = DbOperations::getObject()->fetchData('select subcat_id, subcat_name from test_subcats where under_cat = "' . $tData[0]['under_cat'] . '"');
                                            foreach ($scats as $value) {
                                            ?>
                                            <option<?php echo ($tData[0]['under_subcat'] === $value['subcat_id'] ? ' selected="selected"' : ''); ?> value="<?php echo $value['subcat_id'];?>"><?php echo $value['subcat_name'];?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tname" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Test Name : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <input type="text" class="form-control" id="tname" name="tname" required="required" autocomplete="off" value="<?php echo $tData[0]['test_name']; ?>" placeholder="Name of the test">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tprice" class="col-lg-4 col-md-4 col-sm-5 col-xs-12 control-label">Test Price : </label>
                                    <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <input type="text" class="form-control" id="tprice" name="tprice" required="required" autocomplete="off" value="<?php echo $tData[0]['test_price']; ?>" placeholder="Price of the test in numbers or decimal">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-4 col-md-offset-4 col-sm-offset-5 col-lg-8 col-md-8 col-sm-7 col-xs-12">
                                        <input type="hidden" name="testid" value="<?php echo $tData[0]['test_id']; ?>">
                                        <button type="submit" name="saveTest" id="saveTest" class="btn btn-default">Save Test</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle              = 'Edit a test - JK Diagnostics User Dashboard';
            break;
            
        case 'saveEditedTest':
            // clean the data recieved
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            
            // validate the data
            if (!isset($submittedData['testid']) or empty($submittedData['testid'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'Whoa, No test found like that';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['cat']) or empty($submittedData['cat'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must select a test category';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['scat']) or empty($submittedData['scat'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must select a test sub-category';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            
            if (!isset($submittedData['tname']) or empty($submittedData['tname'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must enter the test name';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['tprice']) or is_nan($submittedData['tprice'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'You must enter the test price in numbers';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            // make a data array to be saves as in database table
            $saveData = array(
                ucwords($submittedData['tname']),
                floatval($submittedData['tprice']),
                $submittedData['cat'],
                $submittedData['scat'],
                $submittedData['testid']
            );
            // start a transaction with database
            DbOperations::getObject()->commitTransaction('start');
            // update the data
            $sql = 'update test_list set test_name = ?, test_price = ?, under_cat = ?, under_subcat = ? where test_id = ?';
            $success                = DbOperations::getObject()->runQuery($sql, $saveData);
            if ($success) {
                // if success commit the transaction and set a message in session
                DbOperations::getObject()->commitTransaction('on');
                $_SESSION['STATUS'] = 'success';
                $_SESSION['MSG']    = 'You have successfully edited the test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            } else {
                // else rollback the data inserted and set an error message in session
                DbOperations::getObject()->commitTransaction('rollback');
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'Error occured while editing the test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            break;
        // delete test
        /*case 'del':
            if (!isset($opt['tid']) or empty($opt['tid'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'No test data found to be deleted';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            // start a transaction with database
            DbOperations::getObject()->commitTransaction('start');
            // update the data
            $sql = 'delete from test_list where test_id = ?';
            $success                = DbOperations::getObject()->runQuery($sql, array($opt['tid']));
            if ($success) {
                // if success commit the transaction and set a message in session
                DbOperations::getObject()->commitTransaction('on');
                $_SESSION['STATUS'] = 'success';
                $_SESSION['MSG']    = 'You have successfully deleted the test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            } else {
                // else rollback the data inserted and set an error message in session
                DbOperations::getObject()->commitTransaction('rollback');
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG']    = 'Error occured while deleting the test';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
         * break;
         */
		case 'viewpatho':
			ob_start();
			?>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-top:5px;">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title text-center">Pathology Tests List for Dt:<?php echo CURDATE; ?></h3>
					</div>
					<table class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th>Sl.</th>
								<th>Mobile</th>
								<th>Name</th>
								<th>Age/Gender</th>
								<th>Tests</th>
								<th class="fixedwidth">Remarks</th>
							</tr>
						<thead>
						<tbody>
						<?php
						$count = 0;
						$sql = 'select distinct(pat_id) as patid from patient_tests, test_list'.
						' where date(pt_dttm) = "' . DBDATE . '"'.
						' and pt_test_id = test_id'.
						' and pt_status = 1 and under_cat = 5'.
						' order by pt_dttm';
						//die($sql);
						$res = DbOperations::getObject()->fetchData($sql);
						/*echo '<pre>';
						print_r($res);
						echo '</pre>';
						exit;*/
						$sql = 'select pid, p_name, p_phone, p_age_yr, p_age_month, p_age_day, p_sex, p_created from patient_details where pid = ?';
						$res1 = DbOperations::getObject()->conn->prepare($sql);
						$sql = 'select test_name'.
						' from test_list left join patient_tests on pt_test_id = test_id'.
						' where pat_id = ? and pt_status = 1 and under_cat = "5" and date(pt_dttm) = "' . DBDATE . '"';
						//die($sql);
						$res2 = DbOperations::getObject()->conn->prepare($sql);
						if (count($res) > 0) {
							foreach ($res as $dat) {
								$res1->execute(array($dat['patid']));
								$data = $res1->fetch();
								$testList = array();
								?>
								<tr>
									<td><?php echo ++$count; ?></td>
									<td><?php echo $data['p_phone'];//date('dmy', strtotime($data['p_created'])) . $data['pid'];?></td>
									<td><?php echo $data['p_name']; ?></td>
									<td><?php echo ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').'&nbsp;/&nbsp;' . $data['p_sex']; ?></td>
									<td>
									<?php
									$res2->execute(array($dat['patid']));
									$tests = $res2->fetchAll();
									foreach ($tests as $testName) {
										$testList[] = $testName['test_name'];
									}
									echo implode(',&nbsp;', $testList);
									?>
									</td>
									<td class="fixedwidth"></td>
								</tr>
						<?php }} else { ?>
						<tr><td colspan="6" class="text-center"><h2>No Tests</h2></td></tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
			<?php
			// get contents from buffer
            $contents = ob_get_contents();
            // clean and end the buffer
            ob_end_clean();

            $replacementArray = array(
                'PageTitle' => 'View Pathology Tests - JK Diagnostics User Dashboard',
                'CenterContents' => $contents,
                'CSSHelpers' => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'custom.min.css'),
                'JSHelpers' => array('jquery.min.js', 'bootstrap.min.js', 'custom.min.js')
            );
			assignTemplate($replacementArray, 'pathoPrint.php');
            exit(0);
		    break;
		 
        default:
            ob_start();
            ?>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">View all Tests</div>
                    <div class="panel-body">
                        <table data-get-ajax="respond.php?opt=allTests" class="table table-striped table-bordered table-hover center" id="reportTable">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Sub-category</th>
                                    <th>Price (<span class="fa fa-rupee"></span>)</th>
                                    <th>Created By</th>
                                    <th>Created On</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Sub-category</th>
                                    <th>Price (<span class="fa fa-rupee"></span>)</th>
                                    <th>Created By</th>
                                    <th>Created On</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            $pageTitle                      = 'View all tests - JK Diagnostics User Dashboard';
            break;
    }
} else {
    ob_start();
    ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="panel panel-default">
            <div class="panel-heading">View all Tests</div>
            <div class="panel-body">
                <table data-get-ajax="respond.php?opt=allTests" class="table table-striped table-bordered table-hover center" id="reportTable">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Sub-category</th>
                            <th>Price (<span class="fa fa-rupee"></span>)</th>
                            <th>Created By</th>
                            <th>Created On</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Sub-category</th>
                            <th>Price (<span class="fa fa-rupee"></span>)</th>
                            <th>Created By</th>
                            <th>Created On</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php
    $pageTitle                      = 'View all tests - JK Diagnostics User Dashboard';
}
// get contents from buffer
$contents                           = ob_get_contents();
// clean and end the buffer
ob_end_clean();

$replacementArray                   = array(
    'PageTitle'                     => $pageTitle,
    'ErrorMessages'                 => getAlertMsg(),
    'CenterContents'                => $contents,
    'CSSHelpers'                    => array('bootstrap.min.css', 'bootstrap-theme.min.css', 'font-awesome.min.css', 'dataTables.bootstrap.min.css', 'custom.min.css'),
    'JSHelpers'                     => array('jquery.min.js', 'bootstrap.min.js', 'bootstrap-typeahead.min.js', 'jquery.dataTables.min.js', 'dataTables.bootstrap.min.js', 'custom.min.js')
);

assignTemplate($replacementArray);
// the ending php tag has been intentionally not used to avoid unwanted whitespaces before document starts
