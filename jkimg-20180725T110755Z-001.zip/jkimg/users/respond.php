<?php
/**
 * This is the common responder file to respond requests all over the project
 * and it contains the required actions with reuest data that will be commonly used
 * New functionality and actions can be added using class files 
 * 
 * @author Kirti Kumar Nayak <admin@thebestfreelancer.in>
 * @license http://thebestfreelancer.in The Best Freelancer. India
 * @version Build 1.0
 * @package RepresentativeDatabase
 * @copyright (c) 2014, The Best Freelancer
 * @outputBuffering disabled
 */
// common include file required
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'include.php';
// check if user authorized to perform this operation
if (isLogged() !== '2') {
    $_SESSION['STATUS'] = 'error';
    $_SESSION['MSG'] = 'You are unauthorized to do so';
    session_write_close();
    header("Location:" . ACCESS_URL . 'login.php');
    exit;
}
// extract get data to get option by user
$opt = DataFilter::getObject()->cleanData($_GET);
if (isset($opt['opt'])) {
    // switch to data recieved
    switch ($opt['opt']) {
        // if patient names are to be suggested
        case 'patNameSuggest':
            // blank array to hold the patient names
            $names = array();
            // get all the patient names from database
            $patientArr = DbOperations::getObject()->fetchData('select pid, p_name, p_phone from patient_details order by p_name');
            // run a loop to get the patient names
            foreach ($patientArr as $patData) {
                array_push(
                    $names, array(
                    'id' => $patData['pid'],
                    'name' => $patData['p_name'] . ', Contact: ' . $patData['p_phone']
                    )
                );
            }
            // echo the json formatted data for auto suggestion
            echo json_encode($names);
            break;
        // if opted to save the doctor data
        case 'saveNewDoc':
            $respMsg = array();
            // clean the data recieved
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            // validate the data
            if (!isset($submittedData['dname']) or empty($submittedData['dname'])) {
                $respMsg['status'] = 'error';
                $respMsg['message'] = 'You must Enter doctor name';
                die(json_encode($respMsg));
            }
            if (!isset($submittedData['org']) or empty($submittedData['org'])) {
                $respMsg['status'] = 'error';
                $respMsg['message'] = 'You must Enter doctor organization';
                die(json_encode($respMsg));
            }
            if (!isset($submittedData['cont']) or empty($submittedData['cont'])) {
                $respMsg['status'] = 'error';
                $respMsg['message'] = 'You must Enter doctor contact number';
                die(json_encode($respMsg));
            }

            // make a data array to be saves as in database table
            $saveData = array(
                'dr_name' => ucwords($submittedData['dname']),
                'dr_org' => ucwords($submittedData['org']),
                'dr_phone' => $submittedData['cont'],
                'dr_created_by' => $_SESSION['UID'],
                'dr_created' => DBTIMESTAMP
            );
            // start a transaction with database
            DbOperations::getObject()->commitTransaction('start');
            // insert the data
            $success = DbOperations::getObject()->insertData('doctor_details', $saveData);
            if ($success) {
                // if success commit the transaction and set a message in session
                DbOperations::getObject()->commitTransaction('on');
                $respMsg['status'] = 'success';
                $respMsg['message'] = 'Doctor details saved';
                die(json_encode($respMsg));
            } else {
                // else rollback the data inserted and set an error message in session
                DbOperations::getObject()->commitTransaction('rollback');
                $respMsg['status'] = 'error';
                $respMsg['message'] = 'Doctor details could not be saved for some error';
                die(json_encode($respMsg));
            }
            break;

        // reload doctor selectbox
        case 'reloadDrSelectBox':
            $dr = DbOperations::getObject()->fetchData('select dr_id, dr_name, dr_org from doctor_details order by dr_name');
            ?>
            <option value="">Select</option>
            <?php
            foreach ($dr as $drData):
                ?>
                <option value="<?php echo $drData['dr_id']; ?>"><?php echo $drData['dr_name'] . ($drData['dr_org'] === '' ? '' : ' (' . $drData['dr_org'] . ')'); ?></option>
                <?php
            endforeach;
            break;

        case 'loadTests':
            // clean the submitted data
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if ($submittedData['catid'] === '') {
                $subcatSel = '<option value="">All Sub-Category</option>';
            } else {
                $sql = 'select subcat_id, subcat_name from test_subcats where under_cat = "' . $submittedData['catid'] . '" order by subcat_name';
                $scat = DbOperations::getObject()->fetchData($sql);
                $subcatSel = '<option value="">All Sub-Category</option>';
                foreach ($scat as $scatData):
                    $subcatSel .= '<option';
                    $subcatSel .= ($submittedData['subcatid'] === $scatData['subcat_id'] ? ' selected="selected"' : '');
                    $subcatSel .= ' value="' . $scatData['subcat_id'] . '">';
                    $subcatSel .= $scatData['subcat_name'] . '</option>';
                endforeach;
            }
            

            if (($submittedData['catid'] === '') and ($submittedData['subcatid'] !== '' or $submittedData['alphabet'] !== '')) {
                $where = 'where';
            } else {
                $where = 'where under_cat = "' . $submittedData['catid'] . '"';
            }
            if ($submittedData['subcatid'] !== '' and $submittedData['catid'] !== '') {
                $where .= ' and under_subcat = "' . $submittedData['subcatid'] . '"';
            } elseif ($submittedData['subcatid'] !== '' and $submittedData['catid'] === '') {
                $where .= ' under_subcat = "' . $submittedData['subcatid'] . '"';
            }
            if ($submittedData['alphabet'] !== '' and ($submittedData['subcatid'] !== '' or $submittedData['catid'] !== '')) {
                $where .= ' and test_name like "' . $submittedData['alphabet'] . '%"';
            } elseif ($submittedData['alphabet'] !== '' and $submittedData['subcatid'] === '' and $submittedData['catid'] === '') {
                $where .= ' test_name like "' . $submittedData['alphabet'] . '%"';
            }
            $sql = 'select test_id, test_name, test_price from test_list ' . $where . ' order by test_name';
            //die($sql);
            $testList = '';
            $tests = DbOperations::getObject()->fetchData($sql);
            foreach ($tests as $testData):
                $testList .= '<div class="checkbox col-lg-6 col-md-6 col-sm-6 col-xs-12">';
                $testList .= '<label for="test_' . $testData['test_id'] . '_' . $submittedData['patid'] . '">';
                $testList .= '<input type="checkbox" name="test[]" data-price="'. $testData['test_price'] .'" id="test_';
                $testList .= $testData['test_id'] . '_' . $submittedData['patid'] . '"';
                $testList .= ((isset($_SESSION['ASSIGNED_TESTS'][$submittedData['patid']]) and (key_exists($testData['test_id'], $_SESSION['ASSIGNED_TESTS'][$submittedData['patid']]) !== false)) ? ' checked="checked"' : '');
                $testList .= ' value="' . $testData['test_id'] . '" title="' . $testData['test_name'] . '" class="testchk">' . $testData['test_name'];
                $testList .= '</label></div>';
            endforeach;
            echo $subcatSel . '{#####}' . $testList;
            exit;
            break;

        case 'chkTst':
            // clean the submitted data
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            if (!isset($_SESSION['ASSIGNED_TESTS'][$submittedData['pid']]) or !is_array($_SESSION['ASSIGNED_TESTS'][$submittedData['pid']])) {
                $_SESSION['ASSIGNED_TESTS'][$submittedData['pid']] = array();
            }
            if ($submittedData['bopt'] === 'removeCalc') {
                if (key_exists($submittedData['tid'], $_SESSION['ASSIGNED_TESTS'][$submittedData['pid']]) === true) {
                    $_SESSION['ASSIGNED_TESTS'][$submittedData['pid']][$submittedData['tid']] = '0';
                }
            } else {
                //if (key_exists($submittedData['tid'], $_SESSION['ASSIGNED_TESTS'][$submittedData['pid']]) === false) {
                $_SESSION['ASSIGNED_TESTS'][$submittedData['pid']][$submittedData['tid']] = '1';
            }
            $testList = '';
            $count = 0;
            $sumTests = 0;
            foreach ($_SESSION['ASSIGNED_TESTS'][$submittedData['pid']] as $testId => $status) {
                ++$count;
                $sql = 'select test_id, test_name, test_price from test_list where test_id = "' . $testId . '"';
                $tests = DbOperations::getObject()->fetchData($sql);
                if (is_array($tests) and (count($tests) > 0)) {
                    if ($status === '1') {
                        $sumTests += (float)$tests[0]['test_price'];
                        $testList .= '<div class="alert alert-success alert-dismissable testLine" id="selTst_' . $tests[0]['test_id']
                            . '_' . $submittedData['pid'] . '" style="padding:10px;margin:2px">';
                        $testList .= '<div class="row"><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
                        $testList .= $count . '</div>';
                        $testList .= '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">';
                        $testList .= $tests[0]['test_name'] . '</div>';
                        $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3 text-right"><span class="fa fa-rupee"></span>&nbsp;';
                        $testList .= number_format((float)$tests[0]['test_price'], 2, '.', '') . '</div>';
                        $testList .= '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
                        $testList .= '<button type="button" class="close" style="right:0" data-dismiss="alert" aria-hidden="true">&times;</button>';
                        $testList .= '</div></div></div>';
                    } else {
                        $testList .= '<div class="alert alert-warning testLine" id="selTst_' . $tests[0]['test_id']
                            . '_' . $submittedData['pid'] . '" style="padding:10px;margin:2px">';
                        $testList .= '<div class="row"><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
                        $testList .= $count . '</div>';
                        $testList .= '<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">';
                        $testList .= $tests[0]['test_name'] . '</div>';
                        $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3 text-right"><span class="fa fa-rupee"></span>&nbsp;';
                        $testList .= number_format((float)$tests[0]['test_price'], 2, '.', '') . '</div>';
                        $testList .= '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">';
                        $testList .= '</div></div></div>';
                    }
                }
            }
            $testList .= '<div class="row">';
            $testList .= '<div class="col-lg-10 col-md-10 col-sm-10 col-xs-9 text-right">';
            $testList .= 'Total Sum</div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3"><span class="fa fa-rupee"></span>';
            $testList .= '<input type="text" id="totVal" name="totVal" class="no-disp" readonly="readonly" value="';
            $testList .= number_format((float)$sumTests, 2, '.', '') . '"></div></div>';
            $testList .= '<div class="row">';
            $testList .= '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3 text-right">';
            $testList .= 'Apply Discount</div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3 text-right">';
            $testList .= '<input type="text" id="discVal" name="discVal" class="form-control" value="0"></div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3 text-right">';
            $testList .= '<select id="discType" name="discType" class="form-control" onchange="calcDiscount();">';
            $testList .= '<option value="">Select</option>';
            $testList .= '<option value="P">%</option>';
            $testList .= '<option value="R">Rs.</option>';
            $testList .= '</select></div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3" style="padding-top:4px"><span class="fa fa-rupee"></span>';
            $testList .= '<input type="text" id="totDiscVal" name="totDiscVal" class="no-disp" readonly="readonly" value="0.00"></div></div>';
            $testList .= '<div class="row">';
            $testList .= '<div class="col-lg-10 col-md-10 col-sm-10 col-xs-9 text-right">';
            $testList .= 'Grand Total</div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3"><span class="fa fa-rupee"></span>';
            $testList .= '<input type="text" id="grTotVal" name="grTotVal" class="no-disp" readonly="readonly" value="';
            $testList .= number_format((float)$sumTests, 2, '.', '') . '"></div></div>';
            $testList .= '<div class="row">';
            $testList .= '<div class="col-lg-10 col-md-10 col-sm-10 col-xs-9 text-right">Payment Status</div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">';
            $testList .= '<select id="payStat" name="payStat" class="form-control">';
            $testList .= '<option value="1">Paid</option>';
            $testList .= '<option value="0">Credit</option>';
            $testList .= '</select></div></div>';
            $testList .= '<div class="row">';
            $testList .= '<div class="col-lg-10 col-md-10 col-sm-10 col-xs-9 text-right">Precedence No</div>';
            $testList .= '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">';
            $testList .= '<select id="preced" name="preced" class="form-control">';
            $testList .= '<option value="">0</option>';
            $prevNos = DbOperations::getObject()->fetchData('select ptc_preced_no from patient_test_calculations where date(ptc_dttm) = "' . DBDATE . '"');
			$preserved = array();
			foreach ($prevNos as $val) {
				array_push($preserved, intval($val[0]));
			}
			array_unique($preserved);
            for($i = 1; $i < 51; ++$i) {
                if (array_search($i, $preserved) === false) {
                    $testList .= '<option value="' . $i . '">' . $i . '</option>';
                }
            }
            $testList .= '</select></div></div>';
            die($testList);
            break;
        
// CO313076220 - BSNL Complain No
        case 'allTests':
            $sql = 'select test_id, test_name, cat_name, subcat_name, test_price, staff_name, test_created from test_list left join test_subcats on under_subcat = subcat_id left join test_cats on test_list.under_cat = cat_id left join staff_users on test_created_by = staff_id where cat_id not in (3, 5) order by test_name';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        utf8_encode($data['test_name']),
                        $data['cat_name'],
                        $data['subcat_name'],
                        number_format(((float) $data['test_price']), 2, '.', ','),
                        $data['staff_name'],
                        date("d-m-Y", strtotime($data['test_created'])),
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Test Details" class="tip btn btn-xs btn-warning" href="tests.php?opt=edit&tid=' . $data['test_id'] . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        case 'allDocs':
            $sql = 'select dr_id, dr_name, dr_org, dr_created, staff_name from doctor_details left join staff_users on staff_id = dr_created_by order by dr_name';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        utf8_encode($data['dr_name']),
                        $data['dr_org'],
                        $data['staff_name'],
                        date("d-m-Y", strtotime($data['dr_created'])),
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Doctor Details" class="tip btn btn-xs btn-warning" href="doctor.php?opt=edit&did=' . $data['dr_id'] . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        
        case 'allPats':
            $sql = 'select pid, p_name, p_addr, p_age_yr, p_age_month, p_age_day, p_phone, p_sex, p_created from patient_details order by p_created desc';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        $data['p_name'],
                        $data['p_addr'],
                        ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').
                        ($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').
                        ($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').
                        '&nbsp;/&nbsp;' . $data['p_sex'],
                        $data['p_phone'],
                        date("d-m-Y", strtotime($data['p_created'])),
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Patient Details" class="tip btn btn-xs btn-warning" href="patient.php?opt=edit&patid=' . $data['pid'] . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
        
        case 'allPatsToday':
            $sql = 'select pid, p_name, p_addr, p_age_yr,'
            . ' p_age_month, p_age_day, p_phone, p_sex,'
            . ' p_created, ptc_tot_price, ptc_discount, '
            . 'ptc_payment_status, ptc_dttm '
            . 'from patient_details, patient_test_calculations'
            . ' where date(ptc_dttm) = "' . DBDATE . '" '
            . 'and pid = ptc_pat_id '
            . 'and ptc_status = "1" '
            . 'order by ptc_dttm desc';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        date('dmy', strtotime($data['p_created'])) . $data['pid'],
                        $data['p_name'],
                        ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').
                        ($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').
                        ($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').
                        '&nbsp;/&nbsp;' . $data['p_sex'],
                        $data['p_phone'],
                        number_format((floatval($data['ptc_tot_price']) - floatval($data['ptc_discount'])), 2, '.', ','),
                        ($data['ptc_payment_status'] === '1' ? 'Paid' : 'Credit'),
                        date("h:i:s A", strtotime($data['ptc_dttm'])),
                        '<div class="btn-group btn-group-xs" role="group" aria-label="tools"><a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="View This Patient test details" class="tip btn btn-default" href="patient.php?opt=showPatDetDateSpecific&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-search"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="Print This Patient Receipt" class="tip btn btn-default" href="patient.php?opt=printPatReceipt&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-print"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Patient Test Details" class="tip btn btn-warning" href="patient.php?opt=editTestsAssigned&patid=' . $data['pid'] . '&receiptDttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a></div>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        case 'showAnotherDatePatients':
            if (!isset($opt['ts']) or ($opt['ts'] === '')) {
                die(json_encode(array('aaData' => array())));
            }
            $sql = 'select pid, p_name, p_addr, p_age_yr, p_age_month,'
                . ' p_age_day, p_phone, p_sex, p_created, ptc_tot_price,'
                . ' ptc_discount, ptc_payment_status, ptc_dttm '
                . 'from patient_details, patient_test_calculations'
                . ' where date(ptc_dttm) = "' . date('Y-m-d', $opt['ts']) . '"'
                . ' and ptc_status = "1"'
                . ' and pid = ptc_pat_id order by ptc_dttm desc';//die($sql);
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        date('dmy', strtotime($data['p_created'])) . $data['pid'],
                        $data['p_name'],
                        ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').
                        ($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').
                        ($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').
                        '&nbsp;/&nbsp;' . $data['p_sex'],
                        $data['p_phone'],
                        number_format((floatval($data['ptc_tot_price']) - floatval($data['ptc_discount'])), 2, '.', ','),
                        ($data['ptc_payment_status'] === '1' ? 'Paid' : 'Credit'),
                        date("d/m/y h:i:s A", strtotime($data['ptc_dttm'])),
                        '<div class="btn-group btn-group-xs" role="group" aria-label="tools"><a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="View This Patient test details" class="tip btn btn-default" href="patient.php?opt=showPatDetDateSpecific&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-search"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="Print This Patient Receipt" class="tip btn btn-default" href="patient.php?opt=printPatReceipt&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-print"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Patient Test Details" class="tip btn btn-warning" href="patient.php?opt=editTestsAssigned&patid=' . $data['pid'] . '&receiptDttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a></div>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        case 'showRangeDatePatients':
            if (!isset($opt['sts']) or ($opt['sts'] === '')) {
                die(json_encode(array('aaData' => array())));
            }
            if (!isset($opt['ets']) or ($opt['ets'] === '')) {
                die(json_encode(array('aaData' => array())));
            }
            $sql = 'select pid, p_name, p_addr, p_age_yr, p_age_month, '
                . 'p_age_day, p_phone, p_sex, p_created, ptc_tot_price, '
                . 'ptc_discount, ptc_payment_status, ptc_dttm '
                . 'from patient_details, patient_test_calculations '
                . 'where date(ptc_dttm) between "' . date('Y-m-d', $opt['sts']) . '" '
                . 'and "' . date('Y-m-d', $opt['ets']) . '" '
                . 'and pid = ptc_pat_id '
                . 'and ptc_status = "1" '
                . 'order by ptc_dttm desc';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        date('dmy', strtotime($data['p_created'])) . $data['pid'],
                        $data['p_name'],
                        ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').
                        ($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').
                        ($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').
                        '&nbsp;/&nbsp;' . $data['p_sex'],
                        $data['p_phone'],
                        number_format((floatval($data['ptc_tot_price']) - floatval($data['ptc_discount'])), 2, '.', ','),
                        ($data['ptc_payment_status'] === '1' ? 'Paid' : 'Credit'),
                        date("d/m/y h:i:s A", strtotime($data['ptc_dttm'])),
                        '<div class="btn-group btn-group-xs" role="group" aria-label="tools"><a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="View This Patient test details" class="tip btn btn-default" href="patient.php?opt=showPatDetDateSpecific&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-search"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" target="_blank" data-original-title="Print This Patient Receipt" class="tip btn btn-default" href="patient.php?opt=printPatReceipt&patid=' . $data['pid'] . '&dttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-print"></span>' .
                        '</a>' .
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Patient Test Details" class="tip btn btn-warning" href="patient.php?opt=editTestsAssigned&patid=' . $data['pid'] . '&receiptDttm=' . strtotime($data['ptc_dttm']) . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a></div>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        case 'mySelf':
            $sql = 'select pid, p_name, p_addr, p_age_yr, p_age_month, '
            . 'p_age_day, p_phone, p_sex, p_created '
            . 'from patient_details '
            . 'where p_created_by = "' . $_SESSION['UID'] . '" '
            . 'order by p_created desc';
            $testData = DbOperations::getObject()->fetchData($sql);
            $aaData = array();
            if (count($testData) > 0) {
                foreach ($testData as $key => $data) {
                    $aaData[] = array(
                        $data['p_name'],
                        $data['p_addr'],
                        ($data['p_age_yr'] === '0' ? '' : $data['p_age_yr'] . '&nbsp;Yrs').
                        ($data['p_age_month'] === '0' ? '' : '&nbsp;' . $data['p_age_month'] . '&nbsp;Months').
                        ($data['p_age_day'] === '0' ? '' : '&nbsp;' . $data['p_age_day'] . '&nbsp;Days').
                        '&nbsp;/&nbsp;' . $data['p_sex'],
                        $data['p_phone'],
                        date("d-m-Y", strtotime($data['p_created'])),
                        '<a data-placement="top" data-toggle="tooltip" data-original-title="Edit This Patient Details" class="tip btn btn-xs btn-warning" href="patient.php?opt=edit&patid=' . $data['pid'] . '">' .
                        '<span class="glyphicon glyphicon-pencil"></span>' .
                        '</a>'
                    );
                }
            } else {
                $aaData = '';
            }
            //print_r($aaData);exit;
            // create an array suitable for data
            $outPutArray = array('aaData' => $aaData);
            // output the array in json format
            die(json_encode($outPutArray));
            break;
            
        case 'updateAccount':
            
            // clean the submitted data
            $submittedData = DataFilter::getObject()->cleanData($_POST);
            // validate the data
            if (!isset($submittedData['name']) or empty($submittedData['name'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must Enter your name';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['email']) or ( strlen(filter_var($submittedData['email'], FILTER_VALIDATE_EMAIL)) < 1)) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must Enter your valid E-mail';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['uname']) or empty($submittedData['uname'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must Enter your Username';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['opass']) or empty($submittedData['opass'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must Enter your Old Password';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            if (!isset($submittedData['npass']) or empty($submittedData['npass'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'You must Enter your New Password';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            // check if the old password matches or not
            $sql = 'select uid from users_data where uname = "' . $_SESSION['USERNAME'] . '" and pass = "' . DataFilter::getObject()->pwdHash($submittedData['opass']) . '"';
            $passCheck = DbOperations::getObject()->fetchData($sql);

            if ((count($passCheck) < 0) or ! isset($passCheck[0]['uid'])) {
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'Your old password is wrong';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }

            $sql = 'update users_data set pass = ?, uname = ?, name = ?, email = ? where uid = ?';
            DbOperations::getObject()->commitTransaction('start');
            $success = DbOperations::getObject()->runQuery(
                $sql, array(
                DataFilter::getObject()->pwdHash($submittedData['npass']),
                $submittedData['uname'],
                $submittedData['name'],
                $submittedData['email'],
                $passCheck[0]['uid']
                )
            );
            if ($success) {
                // if success commit the transaction and set a message in session
                DbOperations::getObject()->commitTransaction('on');
                $_SESSION['STATUS'] = 'success';
                $_SESSION['MSG'] = 'You have successfully changed your profile';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            } else {
                // else rollback the data inserted and set an error message in session
                DbOperations::getObject()->commitTransaction('rollback');
                $_SESSION['STATUS'] = 'error';
                $_SESSION['MSG'] = 'Error occured while changing profile';
                session_write_close();
                header("Location:" . $_SERVER['HTTP_REFERER']);
                exit(0);
            }
            break;

        
        default:
            echo 'This is an invalid option dear...';
            break;
    }
} else {
    echo 'This is an invalid option dear...';
}
exit(0);
